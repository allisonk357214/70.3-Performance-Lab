"""Select the most recent *complete* Oura main sleep period for the nightly card.

Oura's daily_sleep (Sleep Score) and sleep (period detail) endpoints are
independent. A newer score may arrive before its matching detailed period.
Never combine a score from one day with the stages/HRV of another day.
"""
from __future__ import annotations

from datetime import datetime
import json
from pathlib import Path
import sqlite3


def _as_dict(value):
    if isinstance(value, dict):
        return value
    try:
        result = json.loads(value or "{}")
        return result if isinstance(result, dict) else {}
    except (TypeError, ValueError):
        return {}


def _number(value, divisor=1):
    try:
        return None if value is None else float(value) / divisor
    except (TypeError, ValueError):
        return None


def _clock(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).strftime("%I:%M %p").lstrip("0")
    except (TypeError, ValueError):
        return None


def _first(*values):
    return next((v for v in values if v is not None), None)


def load_latest_night(path: Path) -> dict | None:
    """Return a single date-consistent night's score and main sleep detail.

    A main sleep has type long_sleep (preferred). A sufficiently long recorded
    period without that classification is a fallback for historical records.
    Deleted, rejected, and late-nap periods are never treated as overnight.
    """
    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('oura_daily_sleep','oura_sleep_periods')"
        )}
        if not tables:
            return None

        newest_score = (conn.execute(
            "SELECT day,score FROM oura_daily_sleep WHERE score IS NOT NULL ORDER BY day DESC LIMIT 1"
        ).fetchone() if 'oura_daily_sleep' in tables else None)

        newest_period = None
        if 'oura_sleep_periods' in tables:
            # Do not require type='long_sleep' exclusively: older imports or
            # unexpectedly typed main periods can still be sufficiently long.
            newest_period = conn.execute("""
                SELECT day,sleep_type,duration_s,deep_sleep_s,rem_sleep_s,efficiency,
                       average_hrv,average_hr,bedtime_start,bedtime_end,raw_json
                FROM oura_sleep_periods
                WHERE sleep_type='long_sleep'
                   OR (duration_s>=10800 AND
                       (sleep_type IS NULL OR sleep_type NOT IN ('rest','deleted','late_nap')))
                ORDER BY day DESC,
                         CASE WHEN sleep_type='long_sleep' THEN 0 ELSE 1 END,
                         COALESCE(duration_s,0) DESC,bedtime_end DESC
                LIMIT 1
            """).fetchone()

        if not newest_score and not newest_period:
            return None

        latest_score_day = newest_score['day'] if newest_score else None
        latest_score_value = _number(newest_score['score']) if newest_score else None
        detail_day = newest_period['day'] if newest_period else None

        # If today's score is newer than all main sleep periods, show the most
        # recent COMPLETE night with its own score; show newer score separately.
        # Likewise, if a sleep period arrives before its daily score, show its
        # detail with no score rather than borrowing yesterday's score.
        chosen_day = detail_day or latest_score_day
        score_row = (conn.execute(
            "SELECT score,contributors_json FROM oura_daily_sleep WHERE day=?",
            (chosen_day,)
        ).fetchone() if 'oura_daily_sleep' in tables else None)

        period = newest_period if detail_day == chosen_day else None
        raw = _as_dict(period['raw_json']) if period else {}
        contributors = _as_dict(score_row['contributors_json']) if score_row else {}
        col = lambda name: period[name] if period else None

    return {
        'day': chosen_day,
        'score': _number(score_row['score']) if score_row else None,
        'sleep_hours': _number(_first(raw.get('total_sleep_duration'), col('duration_s')), 3600),
        'in_bed_hours': _number(raw.get('time_in_bed'), 3600),
        'efficiency': _number(_first(raw.get('efficiency'), col('efficiency'))),
        'latency_minutes': _number(raw.get('latency'), 60),
        'awake_minutes': _number(raw.get('awake_time'), 60),
        'deep_hours': _number(_first(raw.get('deep_sleep_duration'), col('deep_sleep_s')), 3600),
        'rem_hours': _number(_first(raw.get('rem_sleep_duration'), col('rem_sleep_s')), 3600),
        'light_hours': _number(raw.get('light_sleep_duration'), 3600),
        'average_hrv': _number(_first(raw.get('average_hrv'), col('average_hrv'))),
        'average_hr': _number(_first(raw.get('average_heart_rate'), col('average_hr'))),
        'lowest_hr': _number(raw.get('lowest_heart_rate')),
        'breathing_rate': _number(raw.get('average_breath')),
        'restless_periods': _number(raw.get('restless_periods')),
        'bedtime': _clock(_first(col('bedtime_start'), raw.get('bedtime_start'))),
        'wake_time': _clock(_first(col('bedtime_end'), raw.get('bedtime_end'))),
        'contributors': {k: _number(v) for k, v in contributors.items() if _number(v) is not None},
        'has_period': period is not None,
        'latest_score_day': latest_score_day,
        'latest_score_value': latest_score_value,
        'details_behind_latest_score': bool(latest_score_day and chosen_day < latest_score_day),
    }
