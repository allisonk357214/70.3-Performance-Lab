
from weekly_share import generate_weekly_summary_png


def test_generate_png_bytes():
    sample = {"Swim": 1.5, "Bike": 3.0, "Run": 2.25, "Walk": 1.0, "Strength": 0.75, "Triathlon": 6.75, "Total": 8.5}
    colors = {"Swim": "#3A86FF", "Bike": "#8E6CFF", "Run": "#FF8A3D", "Walk": "#5BB98C", "Strength": "#64748B"}
    png = generate_weekly_summary_png(sample, ["Swim", "Bike", "Run", "Walk", "Strength"], colors, "Nov 18 – Nov 24, 2026")
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
    assert len(png) > 1000
