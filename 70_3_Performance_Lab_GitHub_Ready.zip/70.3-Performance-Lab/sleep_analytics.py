"""Additional nighttime Oura metrics from sleep periods already stored in SQLite.

The v0.4 Oura sync preserved the complete JSON response for each period.
Reading these records means no new API permissions, resync, or table migration
are required to show nightly heart rate, sleep staging, and sleep timing.
"""

from __future__ import annotations

from datetime import datetime, date, timedelta
import json
from pathlib import Path
import sqlite3

import pandas as pd


DETAIL_FIELDS = [
    "sleep_lowest_hr", "sleep_light_hours", "sleep_latency_min",
    "sleep_awake_hours", "sleep_bedtime_clock", "sleep_wake_clock",
    "sleep_bedtime", "sleep_wake_time",
]


def _number(value, divisor=1.0):
    """Preserve missing measurements instead of fabricating zeroes."""
    if value is None:
        return None
    try:
        return float(value) / divisor
    except (ValueError, TypeError):
        return None


def _clock_hours(raw_time: str | None, recorded_day: str) -> tuple[float | None, str | None]:
    """Time as hours since midnight BEFORE the Oura sleep day.

    Bedtime Sun 23:15 -> 23.25; bedtime Mon 00:45 -> 24.75;
    wake Mon 07:15 -> 31.25.  This keeps midnight from causing a
    discontinuity, while honoring the local offset carried in Oura's ISO time.
    """
    if not raw_time:
        return None, None
    try:
        local = datetime.fromisoformat(raw_time.replace("Z", "+00:00"))
        anchor = datetime.combine(date.fromisoformat(recorded_day) - timedelta(days=1), datetime.min.time())
        hours = (local.replace(tzinfo=None) - anchor).total_seconds() / 3600
        return hours, local.strftime("%-I:%M %p")
    except (ValueError, TypeError, OverflowError):
        return None, None


def load_sleep_details(db_path: Path) -> pd.DataFrame:
    """One row per sleep day, selecting the same main period as the v0.4 loader."""
    with sqlite3.connect(db_path) as conn:
        exists = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='oura_sleep_periods'"
        ).fetchone()
        if not exists:
            return pd.DataFrame(columns=DETAIL_FIELDS, index=pd.DatetimeIndex([], name="entry_date"))
        periods = pd.read_sql_query("""
            WITH ranked AS (
                SELECT day, raw_json, bedtime_start, bedtime_end,
                       ROW_NUMBER() OVER (
                           PARTITION BY day
                           ORDER BY CASE WHEN sleep_type='long_sleep' THEN 0 ELSE 1 END,
                                    COALESCE(duration_s, 0) DESC, id
                       ) AS rn
                FROM oura_sleep_periods
            )
            SELECT day, raw_json, bedtime_start, bedtime_end
            FROM ranked WHERE rn=1
            ORDER BY day
        """, conn)

    records = []
    for row in periods.itertuples(index=False):
        try:
            raw = json.loads(row.raw_json or "{}")
        except (json.JSONDecodeError, TypeError):
            raw = {}
        if not isinstance(raw, dict):
            raw = {}
        bedtime_hours, bedtime_display = _clock_hours(row.bedtime_start, row.day)
        wake_hours, wake_display = _clock_hours(row.bedtime_end, row.day)
        records.append({
            "entry_date": pd.Timestamp(row.day),
            "sleep_lowest_hr": _number(raw.get("lowest_heart_rate")),
            "sleep_light_hours": _number(raw.get("light_sleep_duration"), 3600),
            "sleep_latency_min": _number(raw.get("latency"), 60),
            "sleep_awake_hours": _number(raw.get("awake_time"), 3600),
            "sleep_bedtime_clock": bedtime_hours,
            "sleep_wake_clock": wake_hours,
            "sleep_bedtime": bedtime_display,
            "sleep_wake_time": wake_display,
        })
    if not records:
        return pd.DataFrame(columns=DETAIL_FIELDS, index=pd.DatetimeIndex([], name="entry_date"))
    return pd.DataFrame(records).set_index("entry_date").sort_index()


def add_sleep_details(oura_df: pd.DataFrame, db_path: Path) -> pd.DataFrame:
    """Attach detailed fields without changing imported Oura or manual records."""
    details = load_sleep_details(db_path)
    result = oura_df.join(details, how="outer")
    for field in DETAIL_FIELDS:
        if field not in result:
            result[field] = pd.Series(dtype="object" if field in ("sleep_bedtime", "sleep_wake_time") else "float64")
    return result
