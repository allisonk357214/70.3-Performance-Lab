"""Targeted Oura sleep-period backfill for date-window edge cases.

Uses the existing working Oura access token and API client in oura_sync.py.
No new authorization, permissions, or schema changes required.
"""
from __future__ import annotations

from datetime import date, timedelta, datetime, timezone
import json
from pathlib import Path
import sqlite3

from oura_sync import fetch_records, init_oura_db


def refresh_recent_sleep(db_path: Path, days: int = 14) -> dict:
    """Fetch detailed sleep periods with a two-day start buffer.

    Oura's sleep-period date filtering can be based on UTC bedtime_start,
    whereas the returned `day` is Oura's sleep day. Padding the start helps
    recover sessions crossing date/timezone boundaries.

    This is additive/upsert-only and never deletes existing periods or scores.
    """
    if not 1 <= days <= 365:
        raise ValueError("days must be between 1 and 365")
    init_oura_db(db_path)
    today = date.today()
    start = today - timedelta(days=days + 1)
    periods = fetch_records('sleep', start, today)
    now = datetime.now(timezone.utc).isoformat()
    saved = 0
    with sqlite3.connect(db_path) as conn:
        for item in periods:
            period_id, day = item.get('id'), item.get('day')
            if not period_id or not day:
                continue
            conn.execute("""
                INSERT INTO oura_sleep_periods
                 (id,day,sleep_type,duration_s,deep_sleep_s,rem_sleep_s,
                  efficiency,average_hrv,average_hr,bedtime_start,bedtime_end,
                  raw_json,synced_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                  day=excluded.day, sleep_type=excluded.sleep_type,
                  duration_s=excluded.duration_s, deep_sleep_s=excluded.deep_sleep_s,
                  rem_sleep_s=excluded.rem_sleep_s, efficiency=excluded.efficiency,
                  average_hrv=excluded.average_hrv,average_hr=excluded.average_hr,
                  bedtime_start=excluded.bedtime_start,bedtime_end=excluded.bedtime_end,
                  raw_json=excluded.raw_json,synced_at=excluded.synced_at
            """, (period_id, day, item.get('type'), item.get('total_sleep_duration'),
                  item.get('deep_sleep_duration'), item.get('rem_sleep_duration'),
                  item.get('efficiency'), item.get('average_hrv'),
                  item.get('average_heart_rate'), item.get('bedtime_start'),
                  item.get('bedtime_end'), json.dumps(item), now))
            saved += 1
    return {'records_received':len(periods), 'records_saved':saved,
            'start':start.isoformat(), 'end':today.isoformat()}
