"""Conservative, interpretable Garmin/Oura training signals.

This is descriptive monitoring / decision support, not medical clearance,
not an injury predictor, and not a proprietary Garmin load reconstruction.
"""
from __future__ import annotations

from datetime import date, timedelta

import pandas as pd


def daily_training(activities: pd.DataFrame, end_day: date | None = None, days: int = 112) -> pd.DataFrame:
    end_day = end_day or date.today()
    idx = pd.date_range(end=end_day, periods=days, freq="D", name="day")
    result = pd.DataFrame(index=idx, data={"minutes": 0.0, "garmin_load": 0.0, "load_recorded": 0, "sessions": 0})
    if activities.empty:
        return result
    data = activities.copy()
    data["activity_date"] = pd.to_datetime(data["activity_date"], errors="coerce").dt.normalize()
    data = data.loc[data["activity_date"].notna()].copy()
    data["minutes"] = pd.to_numeric(data["duration_s"], errors="coerce").clip(lower=0).fillna(0) / 60
    data["training_load"] = pd.to_numeric(data["training_load"], errors="coerce")
    group = data.groupby("activity_date").agg(
        minutes=("minutes", "sum"),
        garmin_load=("training_load", "sum"),
        load_recorded=("training_load", "count"),
        sessions=("activity_id", "count"),
    )
    for col in result.columns:
        result[col] = group[col].reindex(idx, fill_value=0)
    return result


def trends(daily: pd.DataFrame) -> pd.DataFrame:
    result = daily.copy()
    result["time_7d_avg"] = result["minutes"].rolling(7, min_periods=7).mean()
    result["time_28d_avg"] = result["minutes"].rolling(28, min_periods=28).mean()
    result["time_ratio"] = result["time_7d_avg"] / result["time_28d_avg"].replace(0, float("nan"))
    # Garmin Training Load is summed when provided by Garmin. Sessions with no
    # Garmin load are not imputed; coverage must be displayed alongside it.
    result["garmin_load_7d"] = result["garmin_load"].rolling(7, min_periods=7).sum()
    result["garmin_load_28d"] = result["garmin_load"].rolling(28, min_periods=28).sum()
    result["load_coverage_28d"] = (
        result["load_recorded"].rolling(28, min_periods=28).sum()
        / result["sessions"].rolling(28, min_periods=28).sum().replace(0, float("nan"))
    )
    return result


def _window(series: pd.Series, start: date, end: date, minimum: int):
    if series is None or series.empty:
        return None
    sample = pd.to_numeric(series.loc[(series.index >= pd.Timestamp(start)) & (series.index <= pd.Timestamp(end))], errors="coerce").dropna()
    return float(sample.mean()) if len(sample) >= minimum else None


def readiness_signals(sleep: pd.DataFrame, daily: pd.DataFrame, *, today: date | None = None) -> dict:
    """Illustrative flags only; no universal go/no-go thresholds asserted."""
    today = today or date.today()
    recent_start = today - timedelta(days=6)
    baseline_start = today - timedelta(days=34)
    baseline_end = today - timedelta(days=7)
    signals = []
    context = []
    evaluated = 0
    sleep = sleep.copy()
    if not sleep.empty:
        sleep.index = pd.to_datetime(sleep.index).normalize()
    for column, name, decrease_frac, increase_absolute in [
        ("sleep_score", "Sleep Score", None, -8.0),
        ("sleep_hrv", "Overnight HRV", -0.15, None),
        ("sleep_lowest_hr", "Lowest overnight HR", None, 5.0),
    ]:
        if column not in sleep:
            continue
        recent = _window(sleep[column], recent_start, today, 3)
        baseline = _window(sleep[column], baseline_start, baseline_end, 10)
        if recent is None or baseline is None:
            continue
        evaluated += 1
        if column == "sleep_score":
            context.append(f"Sleep Score {recent:.0f} (recent) vs {baseline:.0f} (previous baseline)")
            if recent - baseline <= -8.0:
                signals.append("Sleep Score is notably below its recent baseline")
        elif column == "sleep_hrv":
            context.append(f"HRV {recent:.0f} vs {baseline:.0f} ms")
            if baseline > 0 and (recent / baseline - 1) <= -0.15:
                signals.append("Overnight HRV is lower than usual")
        else:
            context.append(f"Lowest HR {recent:.0f} vs {baseline:.0f} bpm")
            if recent - baseline >= 5:
                signals.append("Overnight heart rate is higher than usual")
    if not daily.empty:
        last = daily.loc[daily.index <= pd.Timestamp(today)].iloc[-1]
        ratio = last.get("time_ratio")
        if pd.notna(ratio):
            evaluated += 1
            context.append(f"7-day vs 28-day training-time ratio: {ratio:.2f}")
            if ratio > 1.4 and last.get("time_28d_avg", 0) > 0:
                signals.append("Recent training time is elevated vs the preceding month")
    count = len(signals)
    if evaluated < 2:
        headline = "Not enough history for a reliable comparison"
        level = "Insufficient data"
        explanation = "Use the plan as a reference and rely on how you feel, symptoms, and professional guidance."
    elif count >= 2:
        headline = "Consider recovery or reducing planned intensity"
        level = "Review"
        explanation = "Multiple recent trends differ from baseline; reassess hard sessions before proceeding."
    elif count == 1:
        headline = "Review today's harder sessions"
        level = "Monitor"
        explanation = "One training or recovery trend warrants attention; it does not automatically require rest."
    else:
        headline = "No major deviation detected in the measured trends"
        level = "No flag"
        explanation = "This does not certify readiness or override pain, illness, fatigue, or your rehab plan."
    return dict(level=level, headline=headline, explanation=explanation,
                signals=signals, context=context, evaluated=evaluated)
