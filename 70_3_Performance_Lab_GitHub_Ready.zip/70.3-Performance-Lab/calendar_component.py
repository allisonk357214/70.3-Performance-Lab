"""Interactive, drag-to-reschedule weekly calendar for Performance Lab v0.7.3.

Streamlit Components v2 (requires Streamlit >=1.67). All workout strings are
passed as JSON data, not interpolated into trusted JavaScript or HTML.
"""
from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path
import sqlite3

import pandas as pd

SLOTS = ("Morning", "Lunch", "Evening")
ASSETS = Path(__file__).resolve().parent / "calendar_assets"


def make_week_payload(plan: pd.DataFrame, week_start: date, today: date | None = None, matched_ids=None) -> dict:
    """Convert DB rows to strictly JSON-serializable data for the frontend."""
    today = today or date.today()
    matched_ids = set(matched_ids or [])
    prepared: dict[date, list[dict]] = {
        week_start + timedelta(days=offset): [] for offset in range(7)
    }
    if not plan.empty:
        for item in plan.itertuples(index=False):
            day = pd.Timestamp(item.session_date).date()
            if day not in prepared:
                continue
            prepared[day].append({
                "id": int(item.id),
                "slot": str(item.time_slot),
                "category": str(item.category),
                "title": str(item.title),
                "duration_min": int(item.duration_min),
                "intensity": str(item.intensity),
                "status": str(item.status),
                "matched": int(item.id) in matched_ids,
            })
    return {
        "slots": list(SLOTS),
        "days": [
            {
                "date": day.isoformat(),
                "name": day.strftime("%A"),
                "label": f"{day:%b} {day.day}",
                "is_today": day == today,
                "sessions": prepared[day],
            }
            for day in prepared
        ],
    }


def validate_move(db_path: Path, workout_id: int, target_date: str, target_slot: str,
                  week_start: date) -> bool:
    """Check a requested move before backing up. Return whether anything changes."""
    try:
        workout_id = int(workout_id)
        target_day = date.fromisoformat(target_date)
    except (ValueError, TypeError) as exc:
        raise ValueError("Invalid workout or destination date") from exc
    if workout_id <= 0 or target_slot not in SLOTS:
        raise ValueError("Invalid workout or time slot")
    if not (week_start <= target_day <= week_start + timedelta(days=6)):
        raise ValueError("Destination is not in the displayed week")
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT session_date, time_slot FROM planned_sessions WHERE id=?",
            (workout_id,),
        ).fetchone()
    if row is None:
        raise ValueError("This workout no longer exists")
    from_day = date.fromisoformat(row[0])
    if not (week_start <= from_day <= week_start + timedelta(days=6)):
        raise ValueError("This workout is no longer in the displayed week")
    return row != (target_day.isoformat(), target_slot)


def move_workout(db_path: Path, workout_id: int, target_date: str, target_slot: str,
                 week_start: date) -> bool:
    """Atomically move only the date/slot, without touching workout details.

    Checks against the active week and a live DB record, not just browser data.
    Existing session identity, source_key, status, and details remain intact.
    """
    if not validate_move(db_path, workout_id, target_date, target_slot, week_start):
        return False
    workout_id = int(workout_id)
    with sqlite3.connect(db_path) as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            "SELECT session_date, time_slot FROM planned_sessions WHERE id=?",
            (workout_id,),
        ).fetchone()
        if not row or not (week_start.isoformat() <= row[0] <= (week_start + timedelta(days=6)).isoformat()):
            raise ValueError("Workout changed during drag; refresh and try again")
        if row == (target_date, target_slot):
            return False
        result = conn.execute(
            """UPDATE planned_sessions SET session_date=?, time_slot=?,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=? AND session_date=? AND time_slot=?""",
            (target_date, target_slot, workout_id, row[0], row[1]),
        )
        if result.rowcount != 1:
            raise ValueError("Workout changed during drag; refresh and try again")
    return True


def render_week_calendar(plan: pd.DataFrame, week_start: date, matched_ids=None):
    """Mount the V2 component and return its one-time edit/add/move triggers."""
    import streamlit as st

    if not hasattr(st.components, "v2"):
        st.error("The interactive calendar requires a newer Streamlit version. Run: python -m pip install --upgrade streamlit")
        st.stop()

    # The code below is trusted and only ever loaded from the local project files.
    # User-entered workout titles/notes flow separately as JSON data.
    component = st.components.v2.component(
        "performance_lab.week_calendar_v08",
        html='<div id="pl-calendar-root"></div>',
        css=(ASSETS / "calendar.css").read_text(encoding="utf-8"),
        js=(ASSETS / "calendar.js").read_text(encoding="utf-8"),
        isolate_styles=True,
    )
    return component(
        data=make_week_payload(plan, week_start, matched_ids=matched_ids),
        key="performance_lab_week_calendar_v08",
        on_edit_change=lambda: None,
        on_add_change=lambda: None,
        on_move_change=lambda: None,
        width="stretch",
    )
