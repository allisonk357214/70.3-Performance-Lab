"""SQLite-backed triathlon training calendar. Existing health tables are untouched."""
from __future__ import annotations

import csv
import json
from calendar import monthrange
from datetime import date, timedelta
from hashlib import sha256
from io import StringIO
from pathlib import Path
import sqlite3
from datetime import datetime, timezone
from uuid import uuid4
import hashlib

import pandas as pd

SLOTS = ("Morning", "Lunch", "Evening")
CATEGORIES = ("Swim", "Bike", "Run", "Walk", "Strength", "Yoga / Mobility", "Other", "Rest")
INTENSITIES = ("Recovery", "Easy", "Moderate", "Hard")
STATUSES = ("Planned", "Completed", "Skipped")


def monday(day: date) -> date:
    return day - timedelta(days=day.weekday())


def init_plan_db(db_path: Path) -> None:
    with sqlite3.connect(db_path) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS planned_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_date TEXT NOT NULL,
                time_slot TEXT NOT NULL,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                duration_min INTEGER NOT NULL DEFAULT 0,
                intensity TEXT NOT NULL DEFAULT 'Easy',
                planned_rpe REAL,
                notes TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'Planned',
                source_key TEXT UNIQUE,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute("CREATE INDEX IF NOT EXISTS idx_planned_sessions_date ON planned_sessions(session_date)")
        db.executescript("""
            CREATE TABLE IF NOT EXISTS archived_planned_sessions (
                archive_id INTEGER PRIMARY KEY AUTOINCREMENT,
                archive_batch TEXT NOT NULL,
                reason TEXT NOT NULL,
                archived_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                original_id INTEGER NOT NULL,
                session_date TEXT NOT NULL,
                time_slot TEXT NOT NULL,
                category TEXT NOT NULL,
                title TEXT NOT NULL,
                duration_min INTEGER NOT NULL,
                intensity TEXT NOT NULL,
                planned_rpe REAL,
                notes TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL,
                source_key TEXT,
                original_created_at TEXT,
                original_updated_at TEXT,
                garmin_activity_id TEXT,
                match_method TEXT,
                match_matched_at TEXT,
                UNIQUE(archive_batch, original_id)
            );
            CREATE INDEX IF NOT EXISTS idx_archive_session_date
                ON archived_planned_sessions(session_date);
        """)


def _archive_live_range(db: sqlite3.Connection, start: str, end: str,
                        *, reason: str) -> int:
    """Capture existing plan rows and their Garmin links before a destructive edit.

    Must be called inside the caller's SQLite transaction and before DELETE.
    """
    batch = f"{reason}:{datetime.now(timezone.utc).isoformat()}:{uuid4().hex[:8]}"
    cur = db.execute("""
        INSERT INTO archived_planned_sessions
            (archive_batch, reason, original_id, session_date, time_slot, category,
             title, duration_min, intensity, planned_rpe, notes, status,
             source_key, original_created_at, original_updated_at,
             garmin_activity_id, match_method, match_matched_at)
        SELECT ?, ?, p.id, p.session_date, p.time_slot, p.category, p.title,
               p.duration_min, p.intensity, p.planned_rpe, p.notes, p.status,
               p.source_key, p.created_at, p.updated_at,
               m.garmin_activity_id, m.method, m.matched_at
          FROM planned_sessions AS p
          LEFT JOIN session_activity_matches AS m ON m.planned_id = p.id
         WHERE p.session_date BETWEEN ? AND ?
    """, (batch, reason, start, end))
    return cur.rowcount


def load_archived_plan(db_path: Path) -> pd.DataFrame:
    """Historical plan snapshots for viewing/export; never feed training totals."""
    init_plan_db(db_path)
    with sqlite3.connect(db_path) as db:
        return pd.read_sql_query("""
            SELECT archived_at, reason, session_date, time_slot, category,
                   title, duration_min, intensity, planned_rpe, notes,
                   status, garmin_activity_id, match_method,
                   archive_batch, original_id
            FROM archived_planned_sessions
            ORDER BY archived_at DESC, session_date DESC, original_id DESC
        """, db)


def recover_archived_plan_from_backup(
    db_path: Path, backup_path: Path, start: date, end: date,
    *, apply: bool = False,
) -> dict:
    """Copy old planned rows from a pre-replacement backup into archive only.

    The current planned_sessions, Garmin activities/matches, and Oura data
    are never modified. Re-running with the same backup and range is idempotent.
    """
    db_path, backup_path = Path(db_path).resolve(), Path(backup_path).resolve()
    if not db_path.is_file() or not backup_path.is_file():
        raise ValueError("Both the current training.db and backup .db must exist.")
    if db_path == backup_path:
        raise ValueError("The backup and current database cannot be the same file.")
    if not isinstance(start, date) or not isinstance(end, date) or start > end:
        raise ValueError("Select a valid start and end date.")
    if (end - start).days > 730:
        raise ValueError("Select an interval no longer than 731 days.")
    batch = "backup:" + hashlib.sha256(backup_path.read_bytes()).hexdigest()[:24] + f":{start}:{end}"
    with sqlite3.connect(backup_path) as old:
        old.row_factory = sqlite3.Row
        if not old.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='planned_sessions'").fetchone():
            raise ValueError("That backup contains no planned_sessions table.")
        has_matches = bool(old.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='session_activity_matches'").fetchone())
        join = ("LEFT JOIN session_activity_matches AS m ON m.planned_id = p.id" if has_matches else "")
        matching = ("m.garmin_activity_id, m.method AS match_method, m.matched_at AS match_matched_at"
                    if has_matches else
                    "NULL AS garmin_activity_id, NULL AS match_method, NULL AS match_matched_at")
        rows = [dict(r) for r in old.execute(f"""
            SELECT p.id AS original_id, p.session_date, p.time_slot, p.category,
                   p.title, p.duration_min, p.intensity, p.planned_rpe,
                   p.notes, p.status, p.source_key,
                   p.created_at AS original_created_at,
                   p.updated_at AS original_updated_at, {matching}
            FROM planned_sessions AS p {join}
            WHERE p.session_date BETWEEN ? AND ? ORDER BY p.session_date, p.id
        """, (start.isoformat(), end.isoformat())).fetchall()]
    init_plan_db(db_path)
    with sqlite3.connect(db_path) as db:
        present = db.execute("SELECT COUNT(*) FROM archived_planned_sessions WHERE archive_batch=?", (batch,)).fetchone()[0]
        added = 0
        if apply:
            db.execute("BEGIN IMMEDIATE")
            for row in rows:
                cur = db.execute("""
                    INSERT OR IGNORE INTO archived_planned_sessions
                        (archive_batch, reason, original_id, session_date, time_slot,
                         category, title, duration_min, intensity, planned_rpe, notes,
                         status, source_key, original_created_at, original_updated_at,
                         garmin_activity_id, match_method, match_matched_at)
                    VALUES (:archive_batch, :reason, :original_id, :session_date,
                            :time_slot, :category, :title, :duration_min, :intensity,
                            :planned_rpe, :notes, :status, :source_key,
                            :original_created_at, :original_updated_at,
                            :garmin_activity_id, :match_method, :match_matched_at)
                """, {**row, "archive_batch": batch, "reason": "Recovered from pre-replacement backup"})
                added += cur.rowcount
    return {"found": len(rows), "previously_archived": present,
            "added": added, "applied": apply, "examples": rows[:5], "batch": batch}


def validate_session(payload: dict) -> dict:
    try:
        day = date.fromisoformat(str(payload["session_date"])[:10])
    except (ValueError, TypeError, KeyError) as exc:
        raise ValueError("Date must be YYYY-MM-DD.") from exc
    slot = str(payload.get("time_slot", "")).strip().title()
    if slot not in SLOTS:
        raise ValueError(f"Time slot must be one of {', '.join(SLOTS)}.")
    category = str(payload.get("category", "")).strip()
    # Accept common aliases when pasting a plan drafted in ChatGPT.
    category = {"Yoga": "Yoga / Mobility", "Mobility": "Yoga / Mobility", "Cycle": "Bike", "Cycling": "Bike", "Running": "Run", "Swimming": "Swim"}.get(category, category)
    if category not in CATEGORIES:
        raise ValueError(f"Unknown workout type: {category}.")
    title = str(payload.get("title", "")).strip()
    if not title or len(title) > 160:
        raise ValueError("Each workout needs a title (1–160 characters).")
    try:
        minutes = int(payload.get("duration_min", 0))
    except (ValueError, TypeError) as exc:
        raise ValueError("Duration must be a whole number of minutes.") from exc
    if minutes < 0 or minutes > 1440:
        raise ValueError("Duration must be between 0 and 1440 minutes.")
    intensity = str(payload.get("intensity", "Easy") or "Easy").strip().title()
    if intensity not in INTENSITIES:
        raise ValueError(f"Intensity must be one of {', '.join(INTENSITIES)}.")
    status = str(payload.get("status", "Planned") or "Planned").strip().title()
    if status not in STATUSES:
        raise ValueError("Unrecognized session status.")
    raw_rpe = payload.get("planned_rpe")
    try:
        rpe = None if raw_rpe in (None, "") else float(raw_rpe)
    except (ValueError, TypeError) as exc:
        raise ValueError("Planned RPE must be between 0 and 10.") from exc
    if rpe is not None and not 0 <= rpe <= 10:
        raise ValueError("Planned RPE must be between 0 and 10.")
    notes = str(payload.get("notes", "") or "").strip()
    if len(notes) > 4000:
        raise ValueError("Workout notes are too long.")
    return dict(session_date=day.isoformat(), time_slot=slot, category=category,
                title=title, duration_min=minutes, intensity=intensity,
                planned_rpe=rpe, notes=notes, status=status)


def save_session(db_path: Path, data: dict, session_id: int | None = None) -> int:
    item = validate_session(data)
    fields = ("session_date", "time_slot", "category", "title", "duration_min",
              "intensity", "planned_rpe", "notes", "status")
    with sqlite3.connect(db_path) as db:
        if session_id is None:
            cur = db.execute(
                f"INSERT INTO planned_sessions ({', '.join(fields)}) VALUES ({', '.join('?' for _ in fields)})",
                [item[f] for f in fields],
            )
            return cur.lastrowid
        cur = db.execute(
            f"UPDATE planned_sessions SET {', '.join(f'{f}=?' for f in fields)}, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            [item[f] for f in fields] + [int(session_id)],
        )
        if cur.rowcount != 1:
            raise ValueError("Workout not found; it may have been deleted.")
        return int(session_id)


def delete_session(db_path: Path, session_id: int) -> None:
    from session_matching import init_matching_db
    init_matching_db(db_path)
    with sqlite3.connect(db_path) as db:
        row = db.execute("SELECT session_date FROM planned_sessions WHERE id=?", (int(session_id),)).fetchone()
        if not row:
            return
        # Archive just this row rather than every session on its date.
        batch = f"manual_delete:{datetime.now(timezone.utc).isoformat()}:{uuid4().hex[:8]}"
        db.execute("""
            INSERT INTO archived_planned_sessions
                (archive_batch, reason, original_id, session_date, time_slot, category,
                 title, duration_min, intensity, planned_rpe, notes, status, source_key,
                 original_created_at, original_updated_at,
                 garmin_activity_id, match_method, match_matched_at)
            SELECT ?, 'Manual deletion', p.id, p.session_date, p.time_slot, p.category,
                   p.title, p.duration_min, p.intensity, p.planned_rpe, p.notes, p.status,
                   p.source_key, p.created_at, p.updated_at,
                   m.garmin_activity_id, m.method, m.matched_at
            FROM planned_sessions AS p
            LEFT JOIN session_activity_matches AS m ON m.planned_id=p.id
            WHERE p.id=?
        """, (batch, int(session_id)))
        db.execute("DELETE FROM planned_sessions WHERE id=?", (int(session_id),))


def load_plan(db_path: Path, start: date | None = None, end: date | None = None) -> pd.DataFrame:
    init_plan_db(db_path)
    query = "SELECT id, session_date, time_slot, category, title, duration_min, intensity, planned_rpe, notes, status FROM planned_sessions"
    filters, params = [], []
    if start:
        filters.append("session_date>=?")
        params.append(start.isoformat())
    if end:
        filters.append("session_date<=?")
        params.append(end.isoformat())
    if filters:
        query += " WHERE " + " AND ".join(filters)
    query += " ORDER BY session_date, CASE time_slot WHEN 'Morning' THEN 0 WHEN 'Lunch' THEN 1 ELSE 2 END, id"
    with sqlite3.connect(db_path) as db:
        return pd.read_sql_query(query, db, params=params, parse_dates=["session_date"])


def copy_week(db_path: Path, source_monday: date, dest_monday: date, *, replace: bool = False) -> int:
    source_monday, dest_monday = monday(source_monday), monday(dest_monday)
    if source_monday == dest_monday:
        raise ValueError("Choose a different destination week.")
    source = load_plan(db_path, source_monday, source_monday + timedelta(days=6))
    if source.empty:
        raise ValueError("There are no workouts in the source week.")
    destination = load_plan(db_path, dest_monday, dest_monday + timedelta(days=6))
    if not destination.empty and not replace:
        raise ValueError("The destination week already has workouts. Enable Replace destination to overwrite it.")
    if replace:
        from session_matching import init_matching_db
        init_matching_db(db_path)
    with sqlite3.connect(db_path) as db:
        if replace:
            begin, finish = dest_monday.isoformat(), (dest_monday + timedelta(days=6)).isoformat()
            _archive_live_range(db, begin, finish, reason=f"Copy-week replacement {begin} to {finish}")
            db.execute("DELETE FROM planned_sessions WHERE session_date BETWEEN ? AND ?", (begin, finish))
        for s in source.itertuples():
            new_date = dest_monday + timedelta(days=(s.session_date.date() - source_monday).days)
            db.execute("""
                INSERT INTO planned_sessions
                    (session_date, time_slot, category, title, duration_min, intensity, planned_rpe, notes, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Planned')
            """, (new_date.isoformat(), s.time_slot, s.category, s.title,
                  int(s.duration_min), s.intensity, None if pd.isna(s.planned_rpe) else s.planned_rpe, s.notes))
    return len(source)


def parse_plan_csv(csv_text: str) -> list[tuple[dict, str]]:
    """Validate all rows; return (normalized session, stable import key) pairs.

    Existing add-only imports keep their previous skip-duplicate behavior.
    """
    reader = csv.DictReader(StringIO(csv_text.lstrip('\ufeff')))
    if not reader.fieldnames:
        raise ValueError("CSV has no header.")
    records = []
    errors = []
    for line_number, row in enumerate(reader, start=2):
        if not any((v or "").strip() for v in row.values() if isinstance(v, str)):
            continue
        try:
            raw = dict(session_date=row.get("session_date") or row.get("date"),
                       time_slot=row.get("time_slot") or row.get("slot"),
                       category=row.get("category"), title=row.get("title"),
                       duration_min=row.get("duration_min"),
                       intensity=row.get("intensity") or "Easy",
                       planned_rpe=row.get("planned_rpe"), notes=row.get("notes") or "",
                       status="Planned")
            normalized = validate_session(raw)
            ident = str(row.get("source_id") or "").strip()
            if ident:
                key = "source:" + ident
            else:
                signature = "|".join(str(normalized[k]) for k in (
                    "session_date", "time_slot", "category", "title", "duration_min", "intensity"))
                key = "row:" + sha256(signature.encode()).hexdigest()
            records.append((normalized, key))
        except ValueError as exc:
            errors.append(f"Line {line_number}: {exc}")
    if errors:
        raise ValueError("No workouts imported. " + "  ".join(errors[:8]))
    if not records:
        raise ValueError("No workout rows found. An empty CSV cannot replace a plan.")
    if len(records) > 5000:
        raise ValueError("The import is limited to 5,000 workouts at a time.")
    return records


def suggest_csv_month_range(csv_text: str) -> tuple[date, date]:
    """Suggest full calendar-month boundaries for a new dated CSV."""
    records = parse_plan_csv(csv_text)
    days = sorted(date.fromisoformat(item["session_date"]) for item, _ in records)
    first, last = days[0], days[-1]
    return date(first.year, first.month, 1), date(
        last.year, last.month, monthrange(last.year, last.month)[1]
    )


def import_plan_csv(db_path: Path, csv_text: str) -> dict:
    """Original add-only behavior: repeated CSV rows are skipped, not overwritten."""
    records = parse_plan_csv(csv_text)
    added = 0
    with sqlite3.connect(db_path) as db:
        for entry, key in records:
            cur = db.execute("""
                INSERT OR IGNORE INTO planned_sessions
                    (session_date,time_slot,category,title,duration_min,intensity,planned_rpe,notes,status,source_key)
                VALUES (:session_date,:time_slot,:category,:title,:duration_min,:intensity,:planned_rpe,:notes,:status,:source_key)
            """, {**entry, "source_key": key})
            added += cur.rowcount
    return {"added": added, "skipped": len(records) - added}


def _validate_replacement(records: list[tuple[dict, str]], start: date, end: date) -> None:
    if not isinstance(start, date) or not isinstance(end, date) or start > end:
        raise ValueError("Select a valid start and end date (inclusive).")
    if (end - start).days > 730:
        raise ValueError("Choose a replacement range of at most 731 days.")
    outside = [entry["session_date"] for entry, _ in records
               if not start.isoformat() <= entry["session_date"] <= end.isoformat()]
    if outside:
        examples = ", ".join(sorted(set(outside))[:5])
        raise ValueError(
            f"CSV contains workouts outside the selected replacement range: {examples}. "
            "Widen the dates or use a different CSV. Nothing has been changed."
        )
    keys = [key for _, key in records]
    if len(keys) != len(set(keys)):
        raise ValueError(
            "This CSV contains duplicate source IDs or identical rows. "
            "Give each planned session a unique source_id before replacing anything."
        )


def _replacement_state(db: sqlite3.Connection, records: list[tuple[dict, str]],
                       start: date, end: date) -> dict:
    begin, finish = start.isoformat(), end.isoformat()
    # Include the full old records in the preview token, so edits between preview
    # and confirmation cannot silently be removed under a stale preview.
    existing = db.execute("""
        SELECT id,session_date,time_slot,category,title,duration_min,intensity,
               planned_rpe,notes,status,source_key,updated_at
        FROM planned_sessions WHERE session_date BETWEEN ? AND ? ORDER BY id
    """, (begin,finish)).fetchall()
    matches = db.execute("""
        SELECT m.planned_id,m.garmin_activity_id,m.method,m.matched_at
        FROM session_activity_matches m
        JOIN planned_sessions p ON p.id=m.planned_id
        WHERE p.session_date BETWEEN ? AND ? ORDER BY m.planned_id
    """, (begin,finish)).fetchall()
    incoming_keys = [key for _, key in records]
    conflicts = []
    # Chunking avoids SQLite's parameter limit if a large CSV is imported.
    for offset in range(0,len(incoming_keys),400):
        piece = incoming_keys[offset:offset+400]
        placeholders = ",".join("?" for _ in piece)
        conflicts.extend(db.execute(
            f"SELECT session_date,source_key FROM planned_sessions "
            f"WHERE source_key IN ({placeholders}) AND NOT (session_date BETWEEN ? AND ?)",
            [*piece,begin,finish]
        ).fetchall())
    if conflicts:
        samples = ", ".join(f"{day} ({key[:40]})" for day,key in conflicts[:4])
        raise ValueError(
            "One or more CSV source IDs already belong to a workout outside the "
            f"replacement dates: {samples}. Update those source IDs; other months "
            "will not be changed."
        )
    canonical = json.dumps({"dates":[begin,finish],"incoming":records,
                            "existing":existing,"matches":matches},
                           sort_keys=True,default=str,separators=(",",":"))
    token = sha256(canonical.encode("utf-8")).hexdigest()
    return {
        "start": begin, "end":finish,
        "incoming_count":len(records),
        "existing_count":len(existing),
        "existing_link_count":len(matches),
        "incoming_days":len({item["session_date"] for item,_ in records}),
        "incoming_rows":[{**entry,"source_id":key.removeprefix("source:")}
                         for entry,key in records],
        "preview_token":token,
        "linked_activities":[str(item[1]) for item in matches],
    }


def preview_plan_date_range(db_path: Path, csv_text: str, start: date, end: date) -> dict:
    """Read-only validation/preview for explicit range replacement."""
    records = parse_plan_csv(csv_text)
    _validate_replacement(records,start,end)
    init_plan_db(db_path)
    from session_matching import init_matching_db  # no cycle; use the shared schema
    init_matching_db(db_path)
    with sqlite3.connect(db_path) as db:
        return _replacement_state(db,records,start,end)


def replace_plan_date_range(db_path: Path, csv_text: str, start: date, end: date,
                            *, expected_preview_token: str) -> dict:
    """Atomically replace only the selected dates, after a validated preview.

    Old Garmin links are unlinked by the existing planner deletion trigger.
    Previously linked Garmin activities are held from *automatic* re-matching
    to the replacement rows; the user can explicitly relink them in the review UI.
    The Garmin activity records themselves are never modified.
    """
    if not expected_preview_token:
        raise ValueError("Preview the replacement and confirm it first.")
    records = parse_plan_csv(csv_text)
    _validate_replacement(records,start,end)
    init_plan_db(db_path)
    from session_matching import init_matching_db
    init_matching_db(db_path)
    with sqlite3.connect(db_path) as db:
        db.execute("BEGIN IMMEDIATE")
        state = _replacement_state(db,records,start,end)
        if state["preview_token"] != expected_preview_token:
            raise ValueError(
                "The plan or Garmin links changed since your preview. "
                "Please preview again before replacing anything."
            )
        # Explicit holds stop a previously linked Garmin activity from silently
        # linking to a different planned session after this replacement.
        for activity_id in state["linked_activities"]:
            db.execute("""
                INSERT OR IGNORE INTO match_import_holds
                   (garmin_activity_id,range_start,range_end)
                VALUES (?,?,?)
            """, (activity_id,start.isoformat(),end.isoformat()))
        _archive_live_range(
            db, start.isoformat(), end.isoformat(),
            reason=f"Date-range replacement {start.isoformat()} to {end.isoformat()}",
        )
        db.execute("DELETE FROM planned_sessions WHERE session_date BETWEEN ? AND ?",
                   (start.isoformat(),end.isoformat()))
        for entry,key in records:
            db.execute("""
                INSERT INTO planned_sessions
                    (session_date,time_slot,category,title,duration_min,intensity,
                     planned_rpe,notes,status,source_key)
                VALUES (:session_date,:time_slot,:category,:title,:duration_min,
                        :intensity,:planned_rpe,:notes,:status,:source_key)
            """,{**entry,"source_key":key})
    return {
        "removed":state["existing_count"],
        "added":state["incoming_count"],
        "unlinked":state["existing_link_count"],
        "start":state["start"],"end":state["end"],
    }


CSV_TEMPLATE = '''date,slot,category,title,duration_min,intensity,notes,planned_rpe,source_id
2026-11-16,Morning,Walk,Easy walk,25,Recovery,Comfortable pace,2,example-mon-am
2026-11-17,Lunch,Yoga / Mobility,Mobility,20,Easy,Light stretching,,example-tue-lunch
'''
