// 70.3 Performance Lab calendar: pure DOM, no external JS dependencies.
// All session text arrives as data and is placed with textContent (never HTML).
const ICON_ADD = '<path d="M12 5v14M5 12h14"/>';
const PALETTE = { Swim:'#4E98D8', Bike:'#8B72D8', Run:'#48AE8B', Walk:'#E2A45D', Strength:'#D88498', 'Yoga / Mobility':'#AE87CF', Rest:'#99A5B3', Other:'#8095B5' };
const svg = (paths) => `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}
function formatMinutes(value) {
  const n = Number(value) || 0;
  if (n <= 0) return '0 min';
  const hours = Math.floor(n / 60), mins = n % 60;
  return hours ? `${hours}h${mins ? ` ${mins}m` : ''}` : `${mins} min`;
}
export default function(component) {
  const {parentElement, data, setTriggerValue} = component;
  const root = parentElement.querySelector('#pl-calendar-root');
  if (!root) return;
  root.replaceChildren();
  const shell = el('div', 'calendar-shell');
  const grid = el('div', 'week-grid');
  shell.appendChild(grid);
  root.appendChild(shell);
  const week = data?.days || [];
  const slots = data?.slots || ['Morning', 'Lunch', 'Evening'];
  // Click after drag must not accidentally open the edit dialog.
  let dragged = null;
  let blockClickUntil = 0;

  for (const day of week) {
    const column = el('section', `day-card${day.is_today ? ' today' : ''}`);
    const head = el('div', 'day-head');
    head.appendChild(el('div', 'day-name', day.name));
    head.appendChild(el('div', 'day-date', `${day.label}${day.is_today ? ' · Today' : ''}`));
    column.appendChild(head);
    const stack = el('div', 'day-slots');
    for (const slotName of slots) {
      const slot = el('section', 'slot');
      slot.dataset.date = day.date;
      slot.dataset.slot = slotName;
      slot.setAttribute('aria-label', `${day.name} ${slotName} drop target`);
      slot.appendChild(el('div', 'slot-heading', slotName));
      const items = el('div', 'slot-items');
      for (const entry of day.sessions.filter(s => s.slot === slotName)) {
        const card = el('button', 'session');
        card.type = 'button';
        card.draggable = true;
        card.dataset.sessionId = String(entry.id);
        card.style.setProperty('--accent', PALETTE[entry.category] || PALETTE.Other);
        card.title = 'Click to edit · drag to reschedule';
        card.setAttribute('aria-label', `Edit ${entry.title}, ${day.name} ${slotName}`);
        const top = el('div', 'session-top');
        top.appendChild(el('span', 'session-category', entry.category));
        card.appendChild(top);
        card.appendChild(el('div', 'session-title', entry.title));
        card.appendChild(el('div', 'session-meta', `${formatMinutes(entry.duration_min)} · ${entry.intensity}${entry.status !== 'Planned' ? ` · ${entry.status}` : ''}${entry.matched ? ' · Garmin matched' : ''}`));
        card.addEventListener('click', (event) => {
          if (dragged !== null || performance.now() < blockClickUntil) { event.preventDefault(); return; }
          setTriggerValue('edit', {id: entry.id});
        });
        card.addEventListener('dragstart', (event) => {
          dragged = entry.id;
          card.classList.add('dragging');
          if (event.dataTransfer) {
            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/plain', String(entry.id));
          }
        });
        card.addEventListener('dragend', () => {
          blockClickUntil = performance.now() + 380;
          dragged = null;
          card.classList.remove('dragging');
          root.querySelectorAll('.slot.drag-over').forEach(s => s.classList.remove('drag-over'));
        });
        items.appendChild(card);
      }
      slot.appendChild(items);
      const add = el('button', 'add');
      add.type = 'button';
      add.setAttribute('aria-label', `Add workout ${day.name} ${slotName}`);
      const plus = el('span'); plus.innerHTML = svg(ICON_ADD);
      add.appendChild(plus);
      add.appendChild(el('span', '', 'Add'));
      add.addEventListener('click', () => setTriggerValue('add', {date: day.date, slot: slotName}));
      slot.appendChild(add);
      slot.addEventListener('dragenter', (e) => {
        if (!e.dataTransfer || !Array.from(e.dataTransfer.types).includes('text/plain')) return;
        e.preventDefault();
        slot.classList.add('drag-over');
      });
      slot.addEventListener('dragover', (e) => {
        if (dragged === null) return;
        e.preventDefault();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
        slot.classList.add('drag-over');
      });
      slot.addEventListener('dragleave', (e) => {
        if (!slot.contains(e.relatedTarget)) slot.classList.remove('drag-over');
      });
      slot.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        slot.classList.remove('drag-over');
        const fromTransfer = e.dataTransfer?.getData('text/plain');
        const id = Number(fromTransfer || dragged);
        if (!Number.isInteger(id) || id <= 0 || !week.some(d => d.sessions.some(s => s.id === id))) return;
        blockClickUntil = performance.now() + 380;
        dragged = null;
        const original = week.flatMap(d => d.sessions.map(s => ({...s, date: d.date}))).find(s => s.id === id);
        if (original && original.date === day.date && original.slot === slotName) return;
        setTriggerValue('move', {id, date: day.date, slot: slotName});
      });
      stack.appendChild(slot);
    }
    column.appendChild(stack);
    grid.appendChild(column);
  }
  const help = el('div', 'calendar-help', 'Click a session to edit · drag to another slot or day · on touchscreens, tap to change date or slot');
  root.appendChild(help);
}
