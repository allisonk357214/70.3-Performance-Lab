
from __future__ import annotations

from io import BytesIO
from math import ceil
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont


def _load_font(size: int, bold: bool = False):
    candidates = []
    if bold:
        candidates.extend([
            "DejaVuSans-Bold.ttf",
            "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
            "/Library/Fonts/Arial Bold.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        ])
    else:
        candidates.extend([
            "DejaVuSans.ttf",
            "/System/Library/Fonts/Supplemental/Arial.ttf",
            "/Library/Fonts/Arial.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ])
    for path in candidates:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _format_hours(total_hours: float) -> str:
    minutes = int(round(float(total_hours) * 60))
    hours, minutes = divmod(minutes, 60)
    if hours and minutes:
        return f"{hours}h {minutes:02d}m"
    if hours:
        return f"{hours}h"
    return f"{minutes}m"


def _category_entries(week_row, category_order: Iterable[str]):
    entries = []
    for category in category_order:
        raw = week_row.get(category, 0)
        try:
            value = float(raw or 0)
        except Exception:
            value = 0.0
        if value > 0:
            entries.append((category, value))
    return entries


def generate_weekly_summary_png(
    week_row,
    category_order,
    category_colors,
    week_label: str,
    title: str = "Weekly Training Recap",
    canvas_size: int = 1400,
    text_theme: str = "dark",
) -> bytes:
    image = Image.new("RGBA", (canvas_size, canvas_size), (255, 255, 255, 0))
    draw = ImageDraw.Draw(image)

    title_font = _load_font(52, bold=True)
    subtitle_font = _load_font(34, bold=False)
    center_total_font = _load_font(92, bold=True)
    center_label_font = _load_font(34, bold=False)
    legend_title_font = _load_font(30, bold=True)
    legend_font = _load_font(28, bold=False)

    if text_theme == "light":
        ink = (255, 255, 255, 255)
        soft = (255, 255, 255, 255)
    else:
        ink = (30, 41, 59, 255)
        soft = (94, 109, 128, 255)

    title_bbox = draw.textbbox((0, 0), title, font=title_font)
    title_w = title_bbox[2] - title_bbox[0]
    draw.text(((canvas_size - title_w) / 2, 88), title, fill=ink, font=title_font)

    subtitle_bbox = draw.textbbox((0, 0), week_label, font=subtitle_font)
    subtitle_w = subtitle_bbox[2] - subtitle_bbox[0]
    draw.text(((canvas_size - subtitle_w) / 2, 156), week_label, fill=soft, font=subtitle_font)

    entries = _category_entries(week_row, category_order)
    total_hours = float(week_row.get("Total", 0) or 0)
    if total_hours <= 0:
        total_hours = sum(v for _, v in entries)

    donut_center = (canvas_size // 2, 505)
    outer_radius = 280
    inner_radius = 175
    donut_box = [
        donut_center[0] - outer_radius,
        donut_center[1] - outer_radius,
        donut_center[0] + outer_radius,
        donut_center[1] + outer_radius,
    ]
    inner_box = [
        donut_center[0] - inner_radius,
        donut_center[1] - inner_radius,
        donut_center[0] + inner_radius,
        donut_center[1] + inner_radius,
    ]

    if entries:
        start = -90.0
        total = sum(v for _, v in entries) or 1.0
        for category, value in entries:
            sweep = 360.0 * value / total
            color = category_colors.get(category, "#7E8CA0")
            draw.pieslice(donut_box, start=start, end=start + sweep, fill=color)
            start += sweep
    else:
        draw.pieslice(donut_box, start=0, end=360, fill="#D9E2EC")

    draw.ellipse(inner_box, fill=(255, 255, 255, 0))

    total_text = _format_hours(total_hours)
    total_bbox = draw.textbbox((0, 0), total_text, font=center_total_font)
    total_w = total_bbox[2] - total_bbox[0]
    total_h = total_bbox[3] - total_bbox[1]
    draw.text((donut_center[0] - total_w / 2, donut_center[1] - total_h / 2 - 24), total_text, fill=ink, font=center_total_font)
    label = "total this week"
    label_bbox = draw.textbbox((0, 0), label, font=center_label_font)
    label_w = label_bbox[2] - label_bbox[0]
    draw.text((donut_center[0] - label_w / 2, donut_center[1] + 48), label, fill=soft, font=center_label_font)

    breakdown_text = "Breakdown"
    breakdown_bbox = draw.textbbox((0, 0), breakdown_text, font=legend_title_font)
    breakdown_w = breakdown_bbox[2] - breakdown_bbox[0]
    draw.text(((canvas_size - breakdown_w) / 2, 845), breakdown_text, fill=ink, font=legend_title_font)

    if entries:
        cols = 2 if len(entries) > 3 else 1
        rows = ceil(len(entries) / cols)
        col_width = 360
        start_y = 905
        row_gap = 74
        grid_width = cols * col_width
        start_x = (canvas_size - grid_width) / 2
        for idx, (category, value) in enumerate(entries):
            col = idx // rows
            row = idx % rows
            x = start_x + col * col_width
            y = start_y + row * row_gap
            color = category_colors.get(category, "#7E8CA0")
            draw.rounded_rectangle((x, y + 6, x + 24, y + 30), radius=8, fill=color)
            draw.text((x + 42, y), category, fill=ink, font=legend_font)
            value_text = _format_hours(value)
            vb = draw.textbbox((0, 0), value_text, font=legend_font)
            vw = vb[2] - vb[0]
            draw.text((x + col_width - vw - 14, y), value_text, fill=soft, font=legend_font)
    else:
        msg = "No recorded activity this week yet."
        mb = draw.textbbox((0, 0), msg, font=legend_font)
        mw = mb[2] - mb[0]
        draw.text(((canvas_size - mw) / 2, 915), msg, fill=soft, font=legend_font)

    stream = BytesIO()
    image.save(stream, format="PNG")
    return stream.getvalue()
