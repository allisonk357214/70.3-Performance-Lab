"""Safely recover superseded plan history from a pre-replacement SQLite backup.

This appends records to archived_planned_sessions. It NEVER modifies the active
training plan, Garmin activity history, or existing Garmin matches.

Example preview:
    python recover_plan_history.py --backup data/backups/training_<...>_before_plan_range_replace.db --start 2026-11-01 --end 2026-12-31
Apply after reviewing the preview:
    python recover_plan_history.py --backup "<same backup path>" --start 2026-11-01 --end 2026-12-31 --apply
"""
from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path

from plan_store import recover_archived_plan_from_backup


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--backup', type=Path, required=True, help='Pre-replacement .db snapshot under data/backups/')
    parser.add_argument('--db', type=Path, default=Path(__file__).resolve().parent / 'data' / 'training.db',
                        help='Current dashboard database (default: data/training.db)')
    parser.add_argument('--start', type=date.fromisoformat, required=True, help='Old plan start date YYYY-MM-DD')
    parser.add_argument('--end', type=date.fromisoformat, required=True, help='Old plan end date YYYY-MM-DD')
    parser.add_argument('--apply', action='store_true', help='Append to history after preview; no active sessions are modified')
    args = parser.parse_args()
    try:
        result = recover_archived_plan_from_backup(args.db, args.backup, args.start, args.end, apply=args.apply)
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
    print(f"Backup: {args.backup}")
    print(f"Range: {args.start} to {args.end}")
    print(f"Historical sessions found: {result['found']}")
    print(f"Already archived from this backup: {result['previously_archived']}")
    for row in result['examples']:
        print(f"  {row['session_date']} {row['time_slot']}: {row['title']} ({row['status']})")
    if args.apply:
        print(f"Archived {result['added']} additional sessions. Existing active plan and Garmin links unchanged.")
        print("Open Training Plan → Plan history · archived sessions to review.")
    else:
        print("PREVIEW ONLY. To import these historical sessions, run the same command again with --apply.")


if __name__ == '__main__':
    main()
