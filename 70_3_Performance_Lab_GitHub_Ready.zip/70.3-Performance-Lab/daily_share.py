"""Daily social-share overlays for 70.3 Performance Lab.

Uses existing Garmin activity summaries. Produces a truly transparent 1080x1350
PNG, without image-card backgrounds, images, logos, or handwritten fields.
The color bars match the palette in calendar_assets/calendar.js.
"""
from __future__ import annotations

from datetime import date
from io import BytesIO
import math
from typing import Any

import pandas as pd
from PIL import Image, ImageDraw, ImageFont

# Match the categories in calendar_assets/calendar.js, not Garmin's chart colors.
PLAN_COLORS = {
    "Swim": "#4E98D8",
    "Bike": "#8B72D8",
    "Run": "#48AE8B",
    "Walk": "#E2A45D",
    "Strength": "#D88498",
    "Yoga / Mobility": "#AE87CF",
    "Other": "#8095B5",
}

M_PER_MILE = 1609.344
M_PER_YARD = 0.9144


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    names = (["DejaVuSans-Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"] if bold else
             ["DejaVuSans.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf",
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"])
    for candidate in names:
        try:
            return ImageFont.truetype(candidate, size)
        except OSError:
            pass
    return ImageFont.load_default()


def _finite(value: Any) -> float | None:
    try:
        result = float(value)
        return result if math.isfinite(result) else None
    except (TypeError, ValueError):
        return None


def _duration(seconds: float | None) -> str:
    if seconds is None:
        return "—"
    minutes = max(0, int(round(seconds / 60)))
    hours, mins = divmod(minutes, 60)
    if hours and mins:
        return f"{hours}h {mins:02d}m"
    if hours:
        return f"{hours}h"
    return f"{mins}m"


def _distance(meters: float | None, category: str) -> str:
    if meters is None or meters <= 0:
        return "—"
    if category == "Swim":
        return f"{int(round(meters / M_PER_YARD)):,} yd"
    miles = meters / M_PER_MILE
    return f"{miles:.2f} mi" if miles < 1 else f"{miles:.1f} mi"


def _pace(seconds: float | None, meters: float | None, category: str) -> str:
    if seconds is None or meters is None or seconds <= 0 or meters <= 0:
        return "—"
    denominator = meters / M_PER_YARD / 100 if category == "Swim" else meters / M_PER_MILE
    if denominator <= 0:
        return "—"
    seconds_per_unit = int(round(seconds / denominator))
    mins, secs = divmod(seconds_per_unit, 60)
    unit = "100yd" if category == "Swim" else "mi"
    return f"{mins}:{secs:02d}/{unit}"


def _avg_speed(row: pd.Series, seconds: float | None, meters: float | None) -> str:
    mps = _finite(row.get("avg_speed_m_s"))
    if mps is None or mps <= 0:
        mps = meters / seconds if meters and seconds and seconds > 0 else None
    return f"{mps * 2.2369362921:.1f} mph" if mps and mps > 0 else "—"


def activities_on_day(activities: pd.DataFrame, day: date) -> pd.DataFrame:
    """Select only *completed Garmin activities* on a local calendar date.

    No plan rows are consulted, so a planned but unrecorded session is not shown.
    """
    if activities is None or activities.empty:
        return pd.DataFrame(columns=activities.columns if activities is not None else [])
    dates = pd.to_datetime(activities["activity_date"], errors="coerce").dt.date
    chosen = activities.loc[dates == day].copy()
    if "start_local" in chosen.columns:
        chosen = chosen.sort_values("start_local")
    return chosen


def session_metrics(row: pd.Series) -> tuple[str, list[tuple[str, str]]]:
    """Human-readable activity type and no more than three concise stats."""
    category = str(row.get("category") or "Other")
    category = category if category in PLAN_COLORS else "Other"
    seconds = _finite(row.get("duration_s"))
    meters = _finite(row.get("distance_m"))
    time_value = _duration(seconds)
    if category in ("Run", "Walk", "Swim"):
        return category, [
            (_distance(meters, category), "Distance"),
            (time_value, "Time"),
            (_pace(seconds, meters, category), "Pace"),
        ]
    if category == "Bike":
        return category, [
            (_distance(meters, category), "Distance"),
            (time_value, "Time"),
            (_avg_speed(row, seconds, meters), "Avg speed"),
        ]
    if category in ("Strength", "Yoga / Mobility"):
        # Deliberately no upper/lower/core inference, planned-title information, or RPE.
        return category, [(time_value, "Time")]
    return "Other", [(time_value, "Time")]


def _text_width(draw: ImageDraw.ImageDraw, text: str, font) -> float:
    box = draw.textbbox((0, 0), text, font=font)
    return box[2] - box[0]


def _draw_centered(draw, text: str, y: int, font, color, width: int):
    draw.text(((width - _text_width(draw, text, font)) / 2, y), text, font=font, fill=color)


def _fit_font(draw, text: str, requested_size: int, max_width: int, bold: bool = True):
    size = requested_size
    font = _font(size, bold)
    while size > 22 and _text_width(draw, text, font) > max_width:
        size -= 2
        font = _font(size, bold)
    return font


def generate_daily_summary_png(
    sessions: pd.DataFrame,
    day: date,
    *,
    text_theme: str = "dark",
    width: int = 1080,
    height: int = 1350,
) -> bytes:
    """Return an Instagram-portrait PNG with alpha=0 outside text and bars.

    text_theme='dark': near-black lettering for light photos.
    text_theme='light': white lettering for dark photos.
    """
    if text_theme not in ("dark", "light"):
        raise ValueError("text_theme must be 'dark' or 'light'")
    if sessions is None or sessions.empty:
        raise ValueError("Choose a date with at least one Garmin activity")
    image = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    d = ImageDraw.Draw(image)
    strong = (255, 255, 255, 255) if text_theme == "light" else (25, 32, 44, 255)
    secondary = (255, 255, 255, 245) if text_theme == "light" else (83, 95, 111, 255)
    divider = (255, 255, 255, 120) if text_theme == "light" else (58, 72, 89, 100)

    count = len(sessions)
    durations = pd.to_numeric(sessions["duration_s"], errors="coerce")
    total_seconds = float(durations.clip(lower=0).fillna(0).sum())
    headline = day.strftime("%A")  # Weekday only, not the date
    subtitle = f"{count} {'activity' if count == 1 else 'activities'} · {_duration(total_seconds)} total"
    _draw_centered(d, headline, 134, _font(84, True), strong, width)
    _draw_centered(d, subtitle, 250, _font(39), secondary, width)

    # One picture per day, even for multi-session days: scale the vertical rhythm
    # to accommodate several activities in the standard Instagram 4:5 format.
    top = 365
    bottom = height - 45
    available = bottom - top
    step = min(280, available / count)
    compact = count >= 5
    category_size = 50 if not compact else 37
    value_size = 45 if not compact else 32
    label_size = 25 if not compact else 21
    for index, (_, row) in enumerate(sessions.iterrows()):
        section_y = round(top + index * step)
        category, stats = session_metrics(row)
        accent = PLAN_COLORS.get(category, PLAN_COLORS["Other"])
        d.rounded_rectangle((76, section_y + 7, 90, section_y + max(120, step - 35)), radius=7, fill=accent)
        label_font = _fit_font(d, category, category_size, width - 160)
        d.text((145, section_y), category, fill=strong, font=label_font)

        metric_y = section_y + (76 if not compact else 63)
        if len(stats) == 3:
            positions = ((145, 225), (430, 220), (720, 295))
        else:
            positions = ((145, 340),)
        for (stat_value, stat_label), (x, max_w) in zip(stats, positions):
            value_font = _fit_font(d, stat_value, value_size, max_w)
            d.text((x, metric_y), stat_value, fill=strong, font=value_font)
            d.text((x, metric_y + (57 if not compact else 43)), stat_label,
                   fill=secondary, font=_font(label_size))
        if index < count - 1 and not compact:
            divider_y = int(section_y + step - 25)
            d.line(((145, divider_y), (width - 95, divider_y)), fill=divider, width=2)

    output = BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def make_preview_png(transparent_png: bytes, *, background: str) -> bytes:
    """Opaque preview for the dashboard; does not change the exported PNG."""
    overlay = Image.open(BytesIO(transparent_png)).convert("RGBA")
    base = Image.new("RGBA", overlay.size, background)
    base.alpha_composite(overlay)
    buf = BytesIO()
    base.convert("RGB").save(buf, format="PNG")
    return buf.getvalue()
