# 70.3 Performance Lab

A personal, locally run Streamlit dashboard for planning and reviewing endurance training. It combines Garmin workout and weight data with Oura sleep and recovery data, an editable drag-and-drop weekly calendar, and transparent recap graphics for sharing.

This repository is a **source-code release**. Each person runs a separate copy on their own computer, using their own Garmin/Oura credentials and local database. It is **not** a hosted multi-user service.

## Features

- **Overview:** weekly Garmin training time, sport breakdown, planned sessions today, recovery trends, and body-weight information.
- **Training Plan:** drag-and-drop calendar with morning/lunch/evening workouts, click-to-edit, bulk CSV import, selected-date-range replacement, planned-versus-recorded matching, and archived plan history.
- **Training analysis:** training time trends and available Garmin training-load measurements alongside Oura recovery trends. Training guidance is preliminary and not medical advice.
- **Garmin Sessions:** recent activity summaries, individual session data, and plan matches.
- **Oura Sleep & Recovery:** historical Sleep Score, duration, HRV, overnight heart rate, efficiency and sleep-stage charts when available.
- **Body Weight:** Garmin Connect measurements and historical trends.
- **Social exports:** transparent weekly donut and daily activity recap PNGs, with light-text and dark-text versions, clipboard copy where supported, and PNG downloads.

## Requirements

- **Python 3.12 or newer** (needed for the Garmin Personal API client).
- An internet connection and your own Garmin Connect account to sync Garmin data.
- Your own Oura account with eligible API access to sync Oura data.
- VS Code or any other Python editor; a modern browser for the local Streamlit app.

## Download and run locally

Clone the GitHub repository or download it as a ZIP and extract it. Open the extracted folder in your editor.

On macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

On Windows (PowerShell):

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Then configure your own credentials as described below and start the dashboard:

```bash
python -m streamlit run app.py
```

The dashboard normally opens at <http://localhost:8501>. It creates a fresh local SQLite database in `data/training.db` as needed; no database is included in the repository.

## Set up Garmin and Oura

**Never use the repository owner's credentials.** You must create your own key(s). The example file contains placeholders only.

1. Make a copy of `.streamlit/secrets.toml.example` named `.streamlit/secrets.toml` in the **same `.streamlit` folder**. Replace all placeholder strings with credentials issued to *your* accounts.
2. **Garmin:** Sign in to [Garmin Connect](https://connect.garmin.com/), create a Personal API key using Garmin's account settings (if available for your account), then paste it into `[garmin].personal_api_key` in `secrets.toml`.
3. **Oura:** Create a personal app in the [Oura Developer Portal](https://developer.ouraring.com/). Register this exact redirect URL: `http://localhost:8765/callback`. Paste the Client ID and Client Secret into `[oura]` in `secrets.toml`.
4. Authorize Oura once from the project folder:

   ```bash
   python oura_auth.py
   ```

   Sign in and approve the requested access in the browser. The local authorization script saves tokens privately in `.private/oura_tokens.json`.
5. Launch the Streamlit app as shown above. The dashboard checks for Garmin and Oura data and imports records when configured and connected.

A Garmin key and Oura API permissions are independent: you can configure one source before the other. Do not share the `secrets.toml` file or `.private/` token directory.

## Training plan imports

On **Training Plan**, open the bulk CSV import section and download the CSV template. You can import new workouts with the **Add only** mode, or use **Replace selected date range** to replace a specified period of the active calendar. Review the replacement preview carefully: sessions in that range are removed from the active plan; previous versions are archived by the app.

Garmin workouts are matched to planned sessions where the date, sport and approximate duration are unambiguous. Uncertain matches can be reviewed manually.

## Export a transparent recap

On **Overview**, expand **Share weekly summary graphic** or **Share daily activity graphic**. Both provide black/dark-text and white-text versions for use over photos. Export PNGs or try copying the graphic to the clipboard; clipboard permissions vary by browser. The source remains your imported Garmin activities.

## Local data and privacy

All accounts use **your own locally stored credentials and data**:

| Local path | Purpose | Share on GitHub? |
|---|---|---|
| `.streamlit/secrets.toml` | Your API credentials | **No** |
| `.private/` | Your OAuth access/refresh tokens | **No** |
| `data/` | Your SQLite database and backups | **No** |
| `archive/`, `backups/`, `exports/` | Personal and historical files | **No** |
| `.streamlit/secrets.toml.example` | Placeholder-only instructions | Yes |
| Python modules, `calendar_assets/`, `requirements.txt` | Application code and dependencies | Yes |

The `.gitignore` is designed to keep these private paths out of future commits. **Before publishing, always inspect your staged changes with `git status` and `git diff --cached --name-only`.** `.gitignore` does not remove files already committed to Git history. If a real credential was ever committed, remove it from history and rotate it.

For safety, the application is designed to run locally. Do not deploy it as a public Streamlit site without adding user-specific authentication, secrets management and separate data storage.

## Project structure

```text
70.3-Performance-Lab/
├── app.py
├── calendar_component.py
├── calendar_assets/
│   ├── calendar.js
│   └── calendar.css
├── daily_share.py
├── weekly_share.py
├── garmin_sync.py
├── oura_auth.py
├── oura_sync.py
├── sleep_analytics.py
├── training_analysis.py
├── plan_store.py
├── session_matching.py
├── recover_plan_history.py
├── nightly_sleep.py
├── sleep_refresh.py
├── tests/
│   └── test_weekly_share.py
├── requirements.txt
├── .streamlit/
│   └── secrets.toml.example
├── .gitignore
└── README.md
```

This release intentionally contains **no personal database, health history, backups, tokens, archived versions, or demo/setup wizard**. Its application logic comes directly from the shared working project.
