"""Garmin Connect Personal API: activities, per-session details, and weight.

Weight response parsing updated for Garmin dailyWeightSummaries (v0.6.1).

Uses Garmin's official garmin-connect-personal-api-python client.  We preserve
original API payloads alongside normalized fields for later training analysis.
This module never modifies the existing manual check-in or Oura tables.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
import json
import math
from pathlib import Path
import sqlite3
import tomllib
from typing import Any

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
SECRETS_FILE = BASE_DIR / '.streamlit' / 'secrets.toml'
LB_PER_KG = 2.2046226218
METERS_PER_MILE = 1609.344
CATEGORIES = ('Swim', 'Bike', 'Run', 'Walk', 'Strength', 'Yoga / Mobility', 'Other')
CATEGORY_COLORS = {
    'Swim': '#4389AD', 'Bike': '#6A9D8B', 'Run': '#DB9962',
    'Walk': '#9CA98A', 'Strength': '#967EB7',
    'Yoga / Mobility': '#C79A9C', 'Other': '#8793A1',
}


class GarminError(RuntimeError):
    pass


def is_configured() -> bool:
    try:
        return bool(get_api_key())
    except (GarminError, OSError, ValueError):
        return False


def get_api_key() -> str:
    if not SECRETS_FILE.exists():
        raise GarminError('Add [garmin] personal_api_key to .streamlit/secrets.toml')
    try:
        with SECRETS_FILE.open('rb') as f:
            cfg = tomllib.load(f)
    except (OSError, ValueError) as exc:
        raise GarminError('Could not read .streamlit/secrets.toml') from exc
    key = str(cfg.get('garmin', {}).get('personal_api_key', '')).strip()
    if not key or key.startswith('REPLACE_'):
        raise GarminError('Add your Garmin Personal API key to .streamlit/secrets.toml')
    return key


def api_client():
    """Return two managed context objects. Caller uses nested with blocks."""
    try:
        from garmin_personal_api import GarminPersonalApiClient, PersonalApiAuthenticator
    except ImportError as exc:
        raise GarminError('Install Garmin client: python -m pip install garmin-connect-personal-api-python') from exc
    authenticator = PersonalApiAuthenticator()
    return authenticator, GarminPersonalApiClient


def init_garmin_db(db_path: Path):
    with sqlite3.connect(db_path) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS garmin_activities (
                activity_id TEXT PRIMARY KEY,
                start_local TEXT NOT NULL,
                activity_date TEXT NOT NULL,
                name TEXT,
                type_key TEXT,
                category TEXT NOT NULL,
                duration_s REAL,
                distance_m REAL,
                avg_hr REAL,
                max_hr REAL,
                avg_speed_m_s REAL,
                training_load REAL,
                aerobic_te REAL,
                raw_json TEXT NOT NULL,
                detail_json TEXT,
                fetched_at TEXT NOT NULL
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS garmin_weights (
                entry_date TEXT PRIMARY KEY,
                weight_lb REAL NOT NULL,
                measured_at TEXT,
                raw_json TEXT NOT NULL,
                fetched_at TEXT NOT NULL
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS garmin_sync_status (
                source TEXT PRIMARY KEY,
                last_success_utc TEXT NOT NULL,
                items_seen INTEGER NOT NULL DEFAULT 0
            )
        ''')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_garmin_activity_date ON garmin_activities(activity_date)')


def last_sync(db_path: Path, source: str = 'activities'):
    init_garmin_db(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            'SELECT last_success_utc FROM garmin_sync_status WHERE source=?', (source,)
        ).fetchone()
    if not row:
        return None
    return datetime.fromisoformat(row[0])


def sync_due(db_path: Path, hours: int = 12) -> bool:
    stamps = [last_sync(db_path, src) for src in ('activities', 'weights')]
    return any(s is None or datetime.now(timezone.utc) - s > timedelta(hours=hours) for s in stamps)


def _num(raw):
    try:
        x = float(raw)
        return x if math.isfinite(x) else None
    except (ValueError, TypeError):
        return None


def _first(row: dict, *names):
    for name in names:
        if row.get(name) is not None:
            return row[name]
    return None


def category_for_type(type_key: str | None) -> str:
    """Classify Garmin types without relying on an activity's manually edited name."""
    k = (type_key or '').lower().strip().replace('-', '_').replace(' ', '_')
    if any(t in k for t in ('swim', 'aquathlon')):
        return 'Swim'
    if any(t in k for t in ('cycling', 'biking', 'bicycle', 'virtual_ride', 'bike', 'gravel_ride')):
        return 'Bike'
    if any(t in k for t in ('running', 'run', 'treadmill')):
        return 'Run'
    if any(t in k for t in ('walking', 'hiking', 'walk', 'hike')):
        return 'Walk'
    if any(t in k for t in ('strength', 'weight_training', 'weight_lifting', 'resistance_training', 'functional_training')):
        return 'Strength'
    if any(t in k for t in ('yoga', 'pilates', 'stretch', 'mobility', 'flexibility')):
        return 'Yoga / Mobility'
    return 'Other'


def _activity_type(value) -> str:
    if isinstance(value, dict):
        return str(_first(value, 'typeKey', 'typeName', 'type', 'parentTypeId') or 'other')
    return str(value or 'other')


def normalize_activity(item: dict):
    if not isinstance(item, dict):
        return None
    activity_id = _first(item, 'activityId', 'activityID', 'id')
    if activity_id is None:
        return None
    start = _first(item, 'startTimeLocal', 'startTimeGMT', 'startTime')
    if not start:
        return None
    # Garmin's startTimeLocal is a plain local clock datetime. Do not convert it
    # through UTC: the local DATE determines the training-week grouping.
    start_text = str(start)
    if 'T' in start_text and len(start_text) >= 19:
        start_text = start_text.replace('T', ' ')
    day = start_text[:10]
    try:
        date.fromisoformat(day)
    except ValueError:
        return None
    type_key = _activity_type(item.get('activityType'))
    duration = _num(_first(item, 'duration', 'movingDuration', 'elapsedDuration', 'timerTime'))
    if duration is not None and duration < 0:
        duration = None
    distance = _num(item.get('distance'))
    avg_hr = _num(_first(item, 'averageHR', 'averageHeartRate'))
    max_hr = _num(_first(item, 'maxHR', 'maxHeartRate'))
    avg_speed = _num(_first(item, 'averageSpeed', 'avgSpeed'))
    training_load = _num(_first(item, 'activityTrainingLoad', 'trainingLoad', 'trainingLoadValue'))
    aerobic_te = _num(_first(item, 'aerobicTrainingEffect', 'aerobicTE'))
    return {
        'activity_id': str(activity_id),
        'start_local': start_text,
        'activity_date': day,
        'name': str(item.get('activityName') or type_key.replace('_', ' ').title()),
        'type_key': type_key,
        'category': category_for_type(type_key),
        'duration_s': duration,
        'distance_m': distance,
        'avg_hr': avg_hr,
        'max_hr': max_hr,
        'avg_speed_m_s': avg_speed,
        'training_load': training_load,
        'aerobic_te': aerobic_te,
        'raw_json': json.dumps(item, ensure_ascii=False),
        'fetched_at': datetime.now(timezone.utc).isoformat(),
    }


def _records(payload: Any, keys: tuple[str, ...]) -> list[dict]:
    if isinstance(payload, list):
        return [v for v in payload if isinstance(v, dict)]
    if isinstance(payload, dict):
        for key in keys:
            if isinstance(payload.get(key), list):
                return [v for v in payload[key] if isinstance(v, dict)]
        for v in payload.values():
            if isinstance(v, dict):
                for key in keys:
                    if isinstance(v.get(key), list):
                        return [x for x in v[key] if isinstance(x, dict)]
    return []


def _weight_date(row: dict):
    # calendarDate is preferred when supplied. Garmin also exposes a numeric
    # timestamp for manual entries; interpret it in the computer's local zone.
    stamp = _first(row, 'calendarDate', 'dateWeight', 'date', 'timestampGMT', 'timestampLocal', 'gmtTimestamp', 'timestamp', 'measurementDate')
    if stamp is None:
        return None
    if isinstance(stamp, (int, float)):
        ts = float(stamp)
        if ts > 1e11:
            ts /= 1000
        return datetime.fromtimestamp(ts).date().isoformat()
    s = str(stamp)
    if s[:10].count('-') == 2:
        try:
            return date.fromisoformat(s[:10]).isoformat()
        except ValueError:
            return None
    if s.isdecimal():
        return _weight_date({'date': int(s)})
    return None


def normalize_weight(row: dict):
    if not isinstance(row, dict):
        return None
    day = _weight_date(row)
    if not day:
        return None
    lbs = _num(_first(row, 'weightLb', 'weightLbs', 'weightPounds'))
    if lbs is None:
        kg = _num(_first(row, 'weightKg', 'weightKgs', 'weightKilograms'))
        if kg is not None:
            lbs = kg * LB_PER_KG
    if lbs is None:
        grams = _num(_first(row, 'weightInGrams', 'weightGrams', 'weight'))
        if grams is not None:
            # Garmin weight-service reports mass in grams. Some integrations
            # have used kilograms; only accept conventional magnitude ranges.
            if 10000 <= grams <= 500000:
                lbs = (grams / 1000) * LB_PER_KG
            elif 20 <= grams <= 350:
                lbs = grams * LB_PER_KG
    if lbs is None or not 45 <= lbs <= 1100:
        return None
    measured = _first(row, 'timestampGMT', 'gmtTimestamp', 'timestampLocal', 'localTimestamp', 'date', 'timestamp', 'calendarDate')
    return {
        'entry_date': day,
        'weight_lb': lbs,
        'measured_at': str(measured) if measured is not None else None,
        'raw_json': json.dumps(row, ensure_ascii=False),
        'fetched_at': datetime.now(timezone.utc).isoformat(),
    }


def _save_activities(conn, records: list[dict]):
    for r in records:
        conn.execute('''
            INSERT INTO garmin_activities (
                activity_id, start_local, activity_date, name, type_key, category,
                duration_s, distance_m, avg_hr, max_hr, avg_speed_m_s,
                training_load, aerobic_te, raw_json, fetched_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(activity_id) DO UPDATE SET
                start_local=excluded.start_local,
                activity_date=excluded.activity_date,
                name=excluded.name,
                type_key=excluded.type_key,
                category=excluded.category,
                duration_s=excluded.duration_s,
                distance_m=excluded.distance_m,
                avg_hr=excluded.avg_hr,
                max_hr=excluded.max_hr,
                avg_speed_m_s=excluded.avg_speed_m_s,
                training_load=excluded.training_load,
                aerobic_te=excluded.aerobic_te,
                raw_json=excluded.raw_json,
                fetched_at=excluded.fetched_at
        ''', tuple(r[c] for c in (
            'activity_id','start_local','activity_date','name','type_key','category',
            'duration_s','distance_m','avg_hr','max_hr','avg_speed_m_s',
            'training_load','aerobic_te','raw_json','fetched_at')))


def _save_weights(conn, records: list[dict]):
    for r in records:
        conn.execute('''
            INSERT INTO garmin_weights (entry_date, weight_lb, measured_at, raw_json, fetched_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(entry_date) DO UPDATE SET
                weight_lb=excluded.weight_lb,
                measured_at=excluded.measured_at,
                raw_json=excluded.raw_json,
                fetched_at=excluded.fetched_at
        ''', (r['entry_date'], r['weight_lb'], r['measured_at'], r['raw_json'], r['fetched_at']))


def _write_status(conn, source, num):
    conn.execute('''
        INSERT INTO garmin_sync_status(source, last_success_utc, items_seen)
        VALUES (?, ?, ?)
        ON CONFLICT(source) DO UPDATE SET
            last_success_utc=excluded.last_success_utc,
            items_seen=excluded.items_seen
    ''', (source, datetime.now(timezone.utc).isoformat(), num))


def _fetch_activities(client, start_date: date, end_date: date, page_size=20, max_pages=200):
    all_items = []
    for offset in range(0, page_size * max_pages, page_size):
        payload = client.search_activities(
            start=offset, limit=page_size,
            start_date=start_date.isoformat(), end_date=end_date.isoformat(),
        )
        items = _records(payload, ('activities', 'activityList', 'data'))
        if payload and not items:
            raise GarminError('Garmin returned an unexpected activities response; no records were changed.')
        all_items.extend(items)
        if len(items) < page_size:
            return all_items
    raise GarminError('Garmin activity history exceeded the page limit; no records were changed.')


def _extract_weight_measurements(payload: Any) -> list[dict]:
    """Read Garmin's weight/range response without treating empty days as errors.

    Normal response: {"dailyWeightSummaries": [
        {"summaryDate": "YYYY-MM-DD", "allWeightMetrics": [{"weight": GRAMS, ...}]}
    ]}. Preserve a compatibility path for older flat-format responses.
    """
    if payload is None or payload == {} or payload == []:
        return []
    if isinstance(payload, dict) and 'dailyWeightSummaries' in payload:
        summaries = payload['dailyWeightSummaries']
        if summaries is None:
            return []
        if not isinstance(summaries, list):
            raise GarminError('Garmin weight summaries were not a list; existing weights were kept.')
        records = []
        for summary in summaries:
            if not isinstance(summary, dict):
                raise GarminError('Unexpected Garmin weight-day format; existing weights were kept.')
            measurements = summary.get('allWeightMetrics')
            if measurements is None:
                # Some summary records include only the latest entry.
                latest = summary.get('latestWeight')
                measurements = [latest] if isinstance(latest, dict) else []
            if not isinstance(measurements, list):
                raise GarminError('Unexpected Garmin weight measurements format; existing weights were kept.')
            for item in measurements:
                if not isinstance(item, dict):
                    continue
                item = item.copy()
                if not _weight_date(item) and summary.get('summaryDate'):
                    item['calendarDate'] = summary['summaryDate']
                records.append(item)
        return records
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        for key in ('dateWeightList', 'weightMeasurements', 'measurements', 'weights', 'data'):
            if key in payload and isinstance(payload[key], list):
                return [row for row in payload[key] if isinstance(row, dict)]
    raise GarminError('Garmin returned an unrecognized weight response; existing weights were kept.')


def _weight_sort_key(row: dict):
    """Sort Garmin measurements newest last, without assuming list order."""
    raw = _first(row, 'timestampGMT', 'gmtTimestamp', 'timestampLocal',
                 'localTimestamp', 'date', 'timestamp', 'calendarDate')
    if isinstance(raw, (int, float)):
        stamp = float(raw)
        return stamp / 1000 if stamp > 1e11 else stamp
    if raw is None:
        return 0.0
    try:
        # Garmin usually sends a UTC timestamp with a space or a T.
        parsed = datetime.fromisoformat(str(raw).replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.timestamp()
    except (TypeError, ValueError, OverflowError):
        return 0.0


def _fetch_weights(client, start_date: date, end_date: date, window_days=90):
    all_items = []
    cursor = start_date
    while cursor <= end_date:
        edge = min(cursor + timedelta(days=window_days - 1), end_date)
        payload = client.get_weight_measurements(cursor.isoformat(), edge.isoformat())
        all_items.extend(_extract_weight_measurements(payload))
        cursor = edge + timedelta(days=1)
    # Garmin can return more than one reading for the same day. The database
    # stores one reading per day, so always choose the most recent.
    return sorted(all_items, key=_weight_sort_key)


def sync_garmin(db_path: Path, days: int = 21, *, activities=True, weights=True):
    """Fetch first, then upsert; failures in one stream don't overwrite data.

    API errors are displayed to the user but no credentials/tokens are ever logged.
    """
    init_garmin_db(db_path)
    end = date.today()
    start = end - timedelta(days=days - 1)
    results = {'start': start, 'end': end, 'activities': None, 'weights': None, 'errors': {}}
    key = get_api_key()
    authenticator, Client = api_client()
    with authenticator as auth:
        token = auth.obtain_token(key)
        with Client(token.access_token) as client:
            if activities:
                try:
                    items = _fetch_activities(client, start, end)
                    parsed = [normalize_activity(x) for x in items]
                    parsed = [x for x in parsed if x is not None]
                    # Unexpected all-unparseable shape should not record success.
                    if items and not parsed:
                        raise GarminError('Activity format not recognized. No records were changed.')
                    with sqlite3.connect(db_path) as conn:
                        _save_activities(conn, parsed)
                        _write_status(conn, 'activities', len(parsed))
                    results['activities'] = len(parsed)
                    results['skipped_activities'] = len(items) - len(parsed)
                except Exception as exc:
                    results['errors']['activities'] = str(exc)
            if weights:
                try:
                    items = _fetch_weights(client, start, end)
                    parsed = [normalize_weight(x) for x in items]
                    parsed = [x for x in parsed if x is not None]
                    if items and not parsed:
                        raise GarminError('Weight format not recognized. Existing data was kept.')
                    with sqlite3.connect(db_path) as conn:
                        _save_weights(conn, parsed)
                        _write_status(conn, 'weights', len(parsed))
                    results['weights'] = len(parsed)
                    results['skipped_weights'] = len(items) - len(parsed)
                except Exception as exc:
                    results['errors']['weights'] = str(exc)
    return results


def fetch_activity_detail(db_path: Path, activity_id: str):
    init_garmin_db(db_path)
    key = get_api_key()
    auth, Client = api_client()
    with auth as a:
        token = a.obtain_token(key)
        with Client(token.access_token) as client:
            details = client.get_activity(int(activity_id))
    if not isinstance(details, dict):
        raise GarminError('Garmin returned no activity details.')
    with sqlite3.connect(db_path) as conn:
        updated = conn.execute('''
            UPDATE garmin_activities SET detail_json=? WHERE activity_id=?
        ''', (json.dumps(details, ensure_ascii=False), str(activity_id)))
        if not updated.rowcount:
            raise GarminError('Activity not found in local database.')
    return details


def load_activities(db_path: Path):
    init_garmin_db(db_path)
    with sqlite3.connect(db_path) as conn:
        df = pd.read_sql_query('''
            SELECT activity_id, start_local, activity_date, name, type_key, category,
                   duration_s, distance_m, avg_hr, max_hr, avg_speed_m_s,
                   training_load, aerobic_te, detail_json
            FROM garmin_activities ORDER BY start_local DESC
        ''', conn, parse_dates=['activity_date'])
    if df.empty:
        return df
    df['duration_h'] = df['duration_s'] / 3600
    df['distance_miles'] = df['distance_m'] / METERS_PER_MILE
    df['week_start'] = df['activity_date'] - pd.to_timedelta(df['activity_date'].dt.weekday, unit='D')
    return df


def load_weights(db_path: Path):
    init_garmin_db(db_path)
    with sqlite3.connect(db_path) as conn:
        df = pd.read_sql_query('''
            SELECT entry_date, weight_lb AS garmin_weight_lb
            FROM garmin_weights ORDER BY entry_date
        ''', conn, parse_dates=['entry_date'])
    if df.empty:
        return pd.DataFrame(columns=['garmin_weight_lb'], index=pd.DatetimeIndex([], name='entry_date'))
    return df.set_index('entry_date').sort_index()


def weekly_totals(activities: pd.DataFrame, weeks=None) -> pd.DataFrame:
    """One column per category, zero for weeks with no recorded activities.

    Returns only activity time, not physiological load. Current week starts Mon.
    """
    end_week = pd.Timestamp(date.today()) - pd.Timedelta(days=date.today().weekday())
    start_week = end_week - pd.Timedelta(weeks=(weeks - 1)) if weeks else None
    if activities.empty:
        earliest = start_week if start_week is not None else end_week
        weeks_index = pd.date_range(earliest, end_week, freq='7D', name='week_start')
        data = pd.DataFrame(0.0, index=weeks_index, columns=CATEGORIES)
    else:
        tab = activities.copy()
        tab = tab[tab['duration_h'].notna() & (tab['duration_h'] >= 0)]
        grouped = tab.pivot_table(index='week_start', columns='category', values='duration_h', aggfunc='sum', fill_value=0)
        if grouped.empty:
            earliest = start_week if start_week is not None else end_week
            weeks_index = pd.date_range(earliest, end_week, freq='7D', name='week_start')
            data = pd.DataFrame(0.0, index=weeks_index, columns=CATEGORIES)
            data['Total'] = 0.0
            data['Triathlon'] = 0.0
            return data
        earliest = start_week if start_week is not None else grouped.index.min()
        weeks_index = pd.date_range(earliest, end_week, freq='7D', name='week_start')
        data = grouped.reindex(weeks_index, fill_value=0)
        for col in CATEGORIES:
            if col not in data:
                data[col] = 0.0
        data = data[list(CATEGORIES)].astype(float)
        if start_week is not None:
            data = data.loc[data.index >= start_week]
    data['Total'] = data[list(CATEGORIES)].sum(axis=1)
    data['Triathlon'] = data[['Swim','Bike','Run']].sum(axis=1)
    return data
