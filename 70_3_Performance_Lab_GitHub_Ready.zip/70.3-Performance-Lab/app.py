"""70.3 Performance Lab v1.0 — daily activity share graphics plus plan history.

Run: python -m streamlit run app.py
Needs the existing, working oura_sync.py, garmin_sync.py (v0.6.1), and
sleep_analytics.py beside this file. The existing SQLite data is preserved.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta
from pathlib import Path
from hashlib import sha256
import sqlite3
import tempfile
import base64

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
import streamlit.components.v1 as components

from garmin_sync import (
    CATEGORIES as GARMIN_CATEGORIES, CATEGORY_COLORS, METERS_PER_MILE,
    fetch_activity_detail, init_garmin_db,
    is_configured as garmin_configured, last_sync as garmin_last_sync,
    load_activities, load_weights, sync_due as garmin_sync_due,
    sync_garmin, weekly_totals,
)
from oura_sync import (
    init_oura_db, is_connected as oura_connected,
    last_sync as oura_last_sync, load_oura_sleep,
    sync_due as oura_sync_due, sync_oura,
)
from sleep_analytics import add_sleep_details
from plan_store import (
    CATEGORIES as PLAN_CATEGORIES, CSV_TEMPLATE, INTENSITIES, SLOTS, STATUSES,
    copy_week, delete_session, import_plan_csv, init_plan_db,
    load_plan, load_archived_plan, monday, save_session, suggest_csv_month_range,
    preview_plan_date_range, replace_plan_date_range,
)
from training_analysis import daily_training, readiness_signals, trends
from calendar_component import render_week_calendar, validate_move, move_workout
from weekly_share import generate_weekly_summary_png
from daily_share import activities_on_day, generate_daily_summary_png, make_preview_png
from session_matching import (
    init_matching_db, load_links, suggested_auto_matches, apply_auto_matches,
    load_unmatched_activities, link_session, unlink_session,
)

st.set_page_config(page_title="70.3 Performance Lab", page_icon="🏊", layout="wide")
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
BACKUP_DIR = DATA_DIR / "backups"
DB_PATH = DATA_DIR / "training.db"
DATA_DIR.mkdir(exist_ok=True)
BACKUP_DIR.mkdir(exist_ok=True)

# Styling only: interactive widgets and user data still use native Streamlit.
# Leave room for the built-in toolbar/header so the first controls are not obscured.
st.markdown("""
<style>
/* Let main content reclaim the full viewport when the native sidebar closes. */
[data-testid="stMain"] {
    flex: 1 1 auto !important;
    width: 100% !important;
    min-width: 0 !important;
}
section[data-testid="stMain"] .block-container {
    width: 100% !important;
    max-width: none !important;
    padding: 5.1rem clamp(.85rem, 2vw, 2.2rem) 2.8rem !important;
}
[data-testid="stSidebar"][data-collapsed="false"] {
    width: clamp(210px, 17vw, 255px) !important;
    min-width: clamp(210px, 17vw, 255px) !important;
    max-width: clamp(210px, 17vw, 255px) !important;
}
[data-testid="stSidebar"] [data-testid="stSidebarUserContent"] {
    padding-left: .85rem !important;
    padding-right: .85rem !important;
}
[data-testid="stSidebar"] h1 {font-size: 1.32rem !important; line-height: 1.27;}
[data-testid="stMetricValue"] {font-weight: 680;}
.stButton button {border-radius: .55rem;}

/* Keep native collapse/expand behavior; only resize the *open* sidebar. */
[data-testid="stSidebar"] div[class*="st-key-nav_"] button {
    min-height: 2.75rem;
    width: 100%;
    border-radius: .55rem;
    padding: .5rem .7rem;
    justify-content: flex-start;
    text-align: left;
    font-weight: 600;
    font-size: .88rem;
    border: 1px solid transparent;
}
[data-testid="stSidebar"] div[class*="st-key-nav_"] button[kind="secondary"] {
    background: transparent;
}
[data-testid="stSidebar"] div[class*="st-key-nav_"] button[kind="primary"] {
    background: color-mix(in srgb, var(--primary-color) 18%, transparent);
    color: var(--text-color);
    border-left: 3px solid var(--primary-color);
}
[data-testid="stSidebar"] div[class*="st-key-nav_"] button:hover {
    border-color: var(--primary-color);
}

@media (max-width: 950px) {
    [data-testid="stSidebar"][data-collapsed="false"] {
        width: 215px !important; min-width: 215px !important; max-width: 215px !important;
    }
    section[data-testid="stMain"] .block-container {padding-top: 4.8rem !important;}
}
</style>
""", unsafe_allow_html=True)


def db_backup(label: str = "before_change") -> None:
    """Consistent SQLite snapshot before user edits or API syncs; never drop old tables."""
    if not DB_PATH.exists():
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    path = BACKUP_DIR / f"training_{stamp}_{label}.db"
    with sqlite3.connect(DB_PATH) as source, sqlite3.connect(path) as backup:
        source.backup(backup)
    # Keep pre-replacement snapshots indefinitely. They are the safest fallback
    # for a past plan; the usual 40-file retention applies to other snapshots.
    files = sorted(BACKUP_DIR.glob("training_*.db"))
    temporary_snapshots = [
        f for f in files if "before_plan_range_replace" not in f.name
        and "before_plan_copy" not in f.name
    ]
    for old in temporary_snapshots[:-40]:
        old.unlink()


def database_download_bytes() -> bytes:
    """Provide a consistent SQLite snapshot even if a journal/WAL file exists."""
    with tempfile.TemporaryDirectory() as temp:
        dest = Path(temp) / "training_snapshot.db"
        with sqlite3.connect(DB_PATH) as source, sqlite3.connect(dest) as target:
            source.backup(target)
        return dest.read_bytes()


def load_legacy_measurements() -> pd.DataFrame:
    """Read old manual weight/sleep without exposing check-in or quad pain UI."""
    with sqlite3.connect(DB_PATH) as db:
        table_exists = db.execute("SELECT 1 FROM sqlite_master WHERE name='daily_checkins' AND type='table'").fetchone()
        if not table_exists:
            return pd.DataFrame(columns=["manual_weight_lb", "manual_sleep_score"],
                                index=pd.DatetimeIndex([], name="entry_date"))
        data = pd.read_sql_query(
            "SELECT entry_date, weight_lb AS manual_weight_lb, sleep_score AS manual_sleep_score FROM daily_checkins ORDER BY entry_date",
            db, parse_dates=["entry_date"])
    if data.empty:
        return pd.DataFrame(columns=["manual_weight_lb", "manual_sleep_score"],
                            index=pd.DatetimeIndex([], name="entry_date"))
    return data.set_index("entry_date").sort_index()


def get_measurements() -> pd.DataFrame:
    manual = load_legacy_measurements()
    oura = add_sleep_details(load_oura_sleep(DB_PATH), DB_PATH)
    weights = load_weights(DB_PATH)
    data = manual.join(oura, how="outer").join(weights, how="outer").sort_index()
    # Garmin and Oura remain the primary sources; archived manual readings
    # are preserved as fallback on days without imported measurements.
    for field in ("manual_weight_lb", "manual_sleep_score", "garmin_weight_lb",
                  "oura_sleep_score", "sleep_hours", "sleep_hrv", "sleep_efficiency",
                  "sleep_lowest_hr", "deep_sleep_hours", "rem_sleep_hours",
                  "sleep_light_hours", "sleep_bedtime_clock", "sleep_wake_clock"):
        if field not in data:
            data[field] = pd.Series(index=data.index, dtype=float)
    data["weight_lb"] = pd.to_numeric(data["garmin_weight_lb"], errors="coerce").combine_first(
        pd.to_numeric(data["manual_weight_lb"], errors="coerce"))
    data["sleep_score"] = pd.to_numeric(data["oura_sleep_score"], errors="coerce").combine_first(
        pd.to_numeric(data["manual_sleep_score"], errors="coerce"))
    data["weight_source"] = "—"
    data.loc[data["manual_weight_lb"].notna(), "weight_source"] = "Manual (historical)"
    data.loc[data["garmin_weight_lb"].notna(), "weight_source"] = "Garmin"
    data["sleep_source"] = "—"
    data.loc[data["manual_sleep_score"].notna(), "sleep_source"] = "Manual (historical)"
    data.loc[data["oura_sleep_score"].notna(), "sleep_source"] = "Oura"
    for field, n in [("weight_lb", 7), ("weight_lb", 28),
                     ("sleep_score", 7), ("sleep_hrv", 7),
                     ("sleep_hours", 7), ("sleep_lowest_hr", 7)]:
        output = ("weight_7d" if field == "weight_lb" and n == 7 else
                  "weight_28d" if field == "weight_lb" else field + "_7d")
        data[output] = pd.to_numeric(data[field], errors="coerce").rolling(
            f"{n}D", min_periods=3 if n == 7 else 7).mean()
    return data


def format_time(minutes: float | None) -> str:
    if minutes is None or pd.isna(minutes):
        return "—"
    minutes = int(round(float(minutes)))
    return f"{minutes // 60}h {minutes % 60:02d}m" if minutes >= 60 else f"{minutes}m"


def most_recent(df: pd.DataFrame, column: str):
    if df.empty or column not in df:
        return None, None
    values = pd.to_numeric(df[column], errors="coerce").dropna()
    return (None, None) if values.empty else (float(values.iloc[-1]), values.index[-1])


def calendar_period(df: pd.DataFrame, period: str) -> pd.DataFrame:
    if df.empty or period == "All":
        return df
    days = {"7D": 7, "30D": 30, "90D": 90}[period]
    return df.loc[df.index >= pd.Timestamp(date.today() - timedelta(days=days - 1))]


def plot_trend(df: pd.DataFrame, period: str, raw: str, smoothed: list[tuple[str, str]],
               units: str, key: str, axis_range=None):
    selection = calendar_period(df, period)
    if selection.empty or raw not in selection or selection[raw].dropna().empty:
        st.caption("No measurements in this range.")
        return
    data = selection.asfreq("D")
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=data.index, y=data[raw], name="Daily",
                             mode="lines+markers", line=dict(color="#A6AFBA", width=1.2),
                             marker=dict(size=4), connectgaps=False))
    for i, (field, label) in enumerate(smoothed):
        if field in data and data[field].notna().any():
            fig.add_trace(go.Scatter(x=data.index, y=data[field], name=label,
                                     mode="lines", line=dict(color=["#3779CC", "#55A98E"][i % 2], width=2.7)))
    fig.update_layout(height=290, margin=dict(l=8, r=8, t=16, b=5),
                      hovermode="x unified", legend=dict(orientation="h", y=1.14),
                      yaxis=dict(title=units, range=axis_range), xaxis=dict(title=None))
    st.plotly_chart(fig, use_container_width=True, key=key, config={"displayModeBar": False})


def pie_by_category(week_row: pd.Series, key: str):
    names = [category for category in GARMIN_CATEGORIES if week_row.get(category, 0) > 0]
    if not names:
        st.caption("No Garmin sessions recorded this week.")
        return
    fig = go.Figure(go.Pie(
        labels=names, values=[week_row[x] for x in names], hole=.58,
        sort=False, textinfo="percent", textposition="inside",
        marker=dict(colors=[CATEGORY_COLORS[x] for x in names]),
        hovertemplate="%{label}: %{value:.2f} h<extra></extra>"))
    fig.update_layout(height=270, margin=dict(l=0, r=0, t=3, b=4),
                      legend=dict(orientation="h", y=-.08))
    st.plotly_chart(fig, use_container_width=True, key=key, config={"displayModeBar": False})




def copy_png_component(png_bytes: bytes, key: str) -> None:
    """Render a browser-side copy button for PNG graphics."""
    encoded = base64.b64encode(png_bytes).decode("ascii")
    components.html(
        f"""
        <div style="display:flex;align-items:center;gap:10px;">
          <button id="copy-{key}" style="
              background:#F3F6FA;border:1px solid #D9E2EC;border-radius:10px;
              padding:10px 14px;font-weight:600;cursor:pointer;">
              Copy to clipboard
          </button>
          <span id="copy-status-{key}" style="font-size:0.9rem;color:#58636F;"></span>
        </div>
        <script>
        const button = document.getElementById("copy-{key}");
        const status = document.getElementById("copy-status-{key}");
        button.addEventListener("click", async () => {{
            status.textContent = "Copying…";
            try {{
                const response = await fetch("data:image/png;base64,{encoded}");
                const blob = await response.blob();
                await navigator.clipboard.write([new ClipboardItem({{"image/png": blob}})]);
                status.textContent = "Copied to clipboard";
            }} catch (error) {{
                status.textContent = "Copy blocked here — use Download PNG";
            }}
        }});
        </script>
        """,
        height=66,
    )


def share_weekly_graphic_panel(week_row: pd.Series, week_start_day: date) -> None:
    week_end_day = week_start_day + timedelta(days=6)
    week_label = f"{week_start_day:%b %d} – {week_end_day:%b %d, %Y}"
    png_light = generate_weekly_summary_png(
        week_row=week_row,
        category_order=GARMIN_CATEGORIES,
        category_colors=CATEGORY_COLORS,
        week_label=week_label,
        title="Weekly Training Recap",
        text_theme="dark",
    )
    png_dark = generate_weekly_summary_png(
        week_row=week_row,
        category_order=GARMIN_CATEGORIES,
        category_colors=CATEGORY_COLORS,
        week_label=week_label,
        title="Weekly Training Recap",
        text_theme="light",
    )
    st.markdown("**Transparent share graphic**")
    st.caption("Choose the dark-text version for light photos or the white-text version for dark backgrounds. Both can be copied to your clipboard or downloaded as transparent PNGs.")

    col1, col2 = st.columns(2, vertical_alignment="top")
    with col1:
        st.caption("**For light backgrounds**")
        st.image(png_light, width=330)
        copy_png_component(png_light, f"week-recap-light-{week_start_day.isoformat()}")
        st.download_button(
            "Download PNG · dark text",
            data=png_light,
            file_name=f"weekly_training_recap_light_bg_{week_start_day.isoformat()}.png",
            mime="image/png",
            use_container_width=True,
            key=f"download_weekly_recap_light_{week_start_day.isoformat()}",
        )

    with col2:
        st.caption("**For dark backgrounds**")
        st.image(png_dark, width=330)
        copy_png_component(png_dark, f"week-recap-dark-{week_start_day.isoformat()}")
        st.download_button(
            "Download PNG · white text",
            data=png_dark,
            file_name=f"weekly_training_recap_dark_bg_{week_start_day.isoformat()}.png",
            mime="image/png",
            use_container_width=True,
            key=f"download_weekly_recap_dark_{week_start_day.isoformat()}",
        )



def share_daily_graphic_panel(activities: pd.DataFrame) -> None:
    """Create two copyable transparent overlays for one day of Garmin activities."""
    if activities.empty:
        st.caption("No Garmin activities available yet.")
        return

    dates = pd.to_datetime(activities["activity_date"], errors="coerce").dropna()
    most_recent_day = dates.max().date() if not dates.empty else date.today()
    selected_day = st.date_input(
        "Workout day", value=most_recent_day,
        max_value=date.today(), key="daily_share_selected_date_v10",
    )
    sessions = activities_on_day(activities, selected_day)
    if sessions.empty:
        st.caption("No recorded Garmin activities on this day.")
        return

    seconds = pd.to_numeric(sessions["duration_s"], errors="coerce").fillna(0).clip(lower=0)
    st.caption(f"{len(sessions)} {'activity' if len(sessions) == 1 else 'activities'} · "
               f"{format_time(seconds.sum() / 60)} recorded")

    left, right = st.columns(2)
    for col, theme, preview_label, download_label, suffix, preview_bg in [
        (left, "dark", "For light photos", "Download PNG · dark text", "dark_text", "#e9edf2"),
        (right, "light", "For dark photos", "Download PNG · white text", "white_text", "#18283c"),
    ]:
        with col:
            png_bytes = generate_daily_summary_png(sessions, selected_day, text_theme=theme)
            st.caption(preview_label)
            # Backdrop is ONLY for the on-screen preview; exported PNG remains transparent.
            st.image(make_preview_png(png_bytes, background=preview_bg), width=350)
            copy_png_component(png_bytes, f"daily-{suffix}-{selected_day.isoformat()}")
            st.download_button(
                download_label,
                data=png_bytes,
                file_name=f"daily_training_{selected_day.isoformat()}_{suffix}.png",
                mime="image/png",
                use_container_width=True,
                key=f"daily_download_{suffix}_{selected_day.isoformat()}",
            )


def weekly_sport_bars(weekly: pd.DataFrame, key: str):
    fig = go.Figure()
    for cat in GARMIN_CATEGORIES:
        if weekly[cat].sum() > 0:
            fig.add_trace(go.Bar(x=weekly.index, y=weekly[cat], name=cat,
                                 marker_color=CATEGORY_COLORS[cat],
                                 hovertemplate="%{y:.2f} hours<extra>" + cat + "</extra>"))
    fig.update_layout(barmode="stack", height=340, margin=dict(l=8, r=8, t=15, b=6),
                      xaxis=dict(tickformat="%b %d"), yaxis=dict(title="Hours"),
                      legend=dict(orientation="h", y=1.16), hovermode="x unified")
    st.plotly_chart(fig, use_container_width=True, key=key, config={"displayModeBar": False})


def today_sessions_text(sessions: pd.DataFrame) -> list[str]:
    if sessions.empty:
        return []
    return [f"{s.time_slot} · {s.title} · {format_time(s.duration_min)} · {s.intensity}"
            for s in sessions.itertuples() if s.status != "Skipped"]


def show_recommendation(readiness: dict, planned_today: pd.DataFrame):
    level = readiness["level"]
    st.markdown(f"**{readiness['headline']}**")
    st.caption(readiness["explanation"])
    has_hard = not planned_today.empty and planned_today["intensity"].eq("Hard").any()
    if has_hard and level in ("Monitor", "Review"):
        st.write("**Today has a hard session planned:** consider adjusting it after reviewing the signals below.")
    if readiness["signals"]:
        for signal in readiness["signals"]:
            st.write(f"• {signal}")
    elif readiness["context"]:
        st.caption("No flagged deviations in the available comparisons.")
    if readiness["evaluated"] < 2:
        st.caption("Not enough data to make a trend-based suggestion.")


def show_match_review(week_sessions: pd.DataFrame, links: pd.DataFrame, week_start: date):
    """Manual reconciliation of same-day activity records, plus unlinking."""
    if week_sessions.empty:
        st.caption("No planned sessions in this week.")
        return
    eligible = week_sessions.loc[(week_sessions["category"] != "Rest") &
                                 (week_sessions["status"] != "Skipped")].copy()
    if eligible.empty:
        st.caption("No sessions to match in this week.")
        return
    linked_ids = set(links["planned_id"].astype(int)) if not links.empty else set()
    st.caption(f"{sum(int(i) in linked_ids for i in eligible['id'])} of {len(eligible)} eligible workouts linked to Garmin")
    options = eligible["id"].astype(int).tolist()
    labels = {int(row.id):f"{row.session_date:%a %b %d} · {row.category} · {row.title}"
              for row in eligible.itertuples()}
    choice = st.selectbox("Planned workout", options,
        format_func=lambda sid: labels.get(sid, str(sid)),
        key=f"match_review_session_{week_start.isoformat()}")
    selected = eligible.loc[eligible["id"] == choice].iloc[0]
    existing = links.loc[links["planned_id"] == choice] if not links.empty else pd.DataFrame()
    if not existing.empty:
        row = existing.iloc[0]
        st.write(f"Matched: **{row['activity_name']}** · {format_time(row['actual_minutes'])} · {row['method']}")
        if st.button("Unlink Garmin activity", key=f"unlink_{choice}"):
            db_backup("before_unlink_session")
            unlink_session(DB_PATH, choice)
            st.session_state["toast_message"] = "Activity unlinked"
            st.rerun()
    else:
        day = selected["session_date"].date()
        candidates = load_unmatched_activities(DB_PATH, day)
        if candidates.empty:
            st.caption("No unmatched Garmin activities recorded on this date.")
            return
        matching_type = candidates.loc[candidates["category"] == selected["category"]]
        if not matching_type.empty:
            candidates = matching_type
        else:
            st.caption("No same-type Garmin activities this date; verify the type before linking.")
        ids = candidates["activity_id"].astype(str).tolist()
        candidate_labels = {str(a.activity_id):f"{a.name} · {a.category} · {format_time(a.minutes)} · {a.start_local}"
                            for a in candidates.itertuples()}
        activity_id = st.selectbox("Garmin activity",ids,format_func=lambda k:candidate_labels[k],
                                  key=f"garmin_match_candidate_{choice}")
        if st.button("Link activity",key=f"link_{choice}",type="primary"):
            try:
                db_backup("before_manual_match")
                link_session(DB_PATH, choice, activity_id)
                st.session_state["toast_message"] = "Workout linked to Garmin"
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))


# Dialog is intentionally outside the page code. One modal for both new/edit.
@st.dialog("Workout", width="large")
def workout_editor(session_id: int | None, initial_day: date, initial_slot: str):
    existing = None
    if session_id is not None:
        with sqlite3.connect(DB_PATH) as db:
            db.row_factory = sqlite3.Row
            record = db.execute("SELECT * FROM planned_sessions WHERE id=?", (session_id,)).fetchone()
            existing = dict(record) if record else None
    entry = existing or {}
    with st.form(f"edit_workout_{session_id or 'new'}_{initial_day}_{initial_slot}"):
        left, right = st.columns(2)
        with left:
            day = st.date_input("Date", value=date.fromisoformat(entry["session_date"]) if existing else initial_day)
            slot = st.selectbox("Time slot", SLOTS, index=SLOTS.index(entry.get("time_slot", initial_slot)))
            category = st.selectbox("Workout type", PLAN_CATEGORIES,
                                    index=PLAN_CATEGORIES.index(entry.get("category", "Run")))
            title = st.text_input("Workout", value=entry.get("title", ""), placeholder="Easy bike / Technique swim / Strength")
        with right:
            duration = st.number_input("Minutes", min_value=0, max_value=1440,
                                       value=int(entry.get("duration_min", 45)), step=5)
            intensity = st.selectbox("Intensity", INTENSITIES,
                                     index=INTENSITIES.index(entry.get("intensity", "Easy")))
            status = st.selectbox("Status", STATUSES,
                                  index=STATUSES.index(entry.get("status", "Planned")))
            rpe = st.number_input("Planned RPE (optional)", min_value=0.0, max_value=10.0,
                                  value=float(entry["planned_rpe"]) if existing and entry.get("planned_rpe") is not None else None,
                                  step=0.5, placeholder="Not set")
        notes = st.text_area("Session details", value=entry.get("notes", ""),
                             placeholder="Intervals, target HR/pace, technique focus…")
        saved = st.form_submit_button("Save workout", type="primary")
    if saved:
        try:
            if session_id is not None:
                with sqlite3.connect(DB_PATH) as db:
                    linked = db.execute("""SELECT a.activity_date FROM session_activity_matches m
                                JOIN garmin_activities a ON a.activity_id=m.garmin_activity_id
                                WHERE m.planned_id=?""", (session_id,)).fetchone()
                if linked and linked[0] != day.isoformat():
                    raise ValueError("Unlink the Garmin activity before changing this workout's date")
                if linked and (status != "Completed" or category != entry.get("category")):
                    raise ValueError("Unlink the Garmin activity before changing the status or workout type")
            db_backup("before_plan_edit")
            save_session(DB_PATH, dict(session_date=day.isoformat(), time_slot=slot,
                                      category=category, title=title, duration_min=duration,
                                      intensity=intensity, planned_rpe=rpe,
                                      notes=notes, status=status), session_id)
        except ValueError as exc:
            st.error(str(exc))
        else:
            st.session_state["edit_request"] = None
            st.session_state["toast_message"] = "Workout saved"
            st.rerun()
    if session_id is not None:
        st.divider()
        with st.expander("Delete workout"):
            confirm = st.checkbox("Confirm deletion", key=f"confirm_delete_{session_id}")
            if st.button("Delete", disabled=not confirm, key=f"delete_{session_id}"):
                db_backup("before_plan_delete")
                delete_session(DB_PATH, session_id)
                st.session_state["edit_request"] = None
                st.session_state["toast_message"] = "Workout deleted"
                st.rerun()


# --- Initialize and synchronize existing data sources -----------------------
init_oura_db(DB_PATH)
init_garmin_db(DB_PATH)
init_plan_db(DB_PATH)
init_matching_db(DB_PATH)
oura_error = None
garmin_error = None
if oura_connected():
    try:
        if oura_sync_due(DB_PATH, hours=12):
            db_backup("before_oura_sync")
            sync_oura(DB_PATH, days=365 if oura_last_sync(DB_PATH) is None else 14)
            # Targeted padded fetch handles sleep periods that begin before
            # the daily-score date window, without changing Garmin syncing.
            refresh_recent_sleep(DB_PATH, days=14)
    except Exception as exc:
        oura_error = str(exc)
if garmin_configured():
    try:
        if garmin_sync_due(DB_PATH, hours=12):
            initial = garmin_last_sync(DB_PATH, "activities") is None
            db_backup("before_garmin_sync")
            result = sync_garmin(DB_PATH, days=365 if initial else 21)
            if result.get("errors"):
                garmin_error = "; ".join(f"{k}: {v}" for k, v in result["errors"].items())
    except Exception as exc:
        garmin_error = str(exc)

# Reconcile only unequivocal same-date/type/duration pairs; uncertain sessions
# stay unlinked for the user to review. Existing links are never reassigned.
matching_error = None
new_match_count = 0
try:
    pending_auto = suggested_auto_matches(DB_PATH)
    if pending_auto:
        db_backup("before_auto_matching")
        new_match_count = apply_auto_matches(DB_PATH, pending_auto)
except (ValueError, sqlite3.Error) as exc:
    matching_error = str(exc)

activities = load_activities(DB_PATH)
measurements = get_measurements()
plan = load_plan(DB_PATH)
links = load_links(DB_PATH)
matched_ids = set(links["planned_id"].astype(int)) if not links.empty else set()
weekly = weekly_totals(activities, weeks=16)
week_now = weekly.iloc[-1]
daily = trends(daily_training(activities, days=120))
recommendation = readiness_signals(measurements, daily)
planned_today = load_plan(DB_PATH, date.today(), date.today())
if not planned_today.empty:
    planned_today = planned_today.loc[planned_today["status"] != "Skipped"].copy()

if "toast_message" in st.session_state:
    st.toast(st.session_state.pop("toast_message"))

# The sidebar is intentionally built with native buttons rather than radio controls.
# This keeps navigation in one file and preserves the active page across reruns.
NAVIGATION = [
    ("Overview", ":material/home:", "overview"),
    ("Training Plan", ":material/calendar_month:", "training_plan"),
    ("Load & Recovery", ":material/monitor_heart:", "load_recovery"),
    ("Training Trends", ":material/stacked_bar_chart:", "training_trends"),
    ("Garmin Sessions", ":material/directions_run:", "garmin_sessions"),
    ("Sleep & Recovery", ":material/bedtime:", "sleep_recovery"),
    ("Body Weight", ":material/monitor_weight:", "body_weight"),
    ("Data & Settings", ":material/settings:", "data_settings"),
]


def navigate_to(destination: str) -> None:
    st.session_state["nav_page"] = destination


def page_heading(title: str, range_selector: bool = False) -> str:
    """Place optional range selector alongside, not above, the page title."""
    if not range_selector:
        st.header(title)
        return "30D"
    heading, filter_col = st.columns([5, 1.2], vertical_alignment="bottom")
    with heading:
        st.header(title)
    with filter_col:
        return st.selectbox("Range", ["7D", "30D", "90D", "All"], index=1,
                            key=f"range_{title}", label_visibility="collapsed")


if st.session_state.get("nav_page") not in {item[0] for item in NAVIGATION}:
    st.session_state["nav_page"] = "Overview"

with st.sidebar:
    st.title("70.3 Performance Lab")
    for label, icon, slug in NAVIGATION:
        st.button(
            label, icon=icon,
            key=f"nav_{slug}",
            type="primary" if st.session_state["nav_page"] == label else "secondary",
            use_container_width=True,
            on_click=navigate_to, args=(label,),
        )
    st.divider()
    if garmin_configured():
        st.caption("Garmin · connected")
    if oura_connected():
        st.caption("Oura · connected")

page = st.session_state["nav_page"]

# --- Overview ---------------------------------------------------------------
if page == "Overview":
    period = page_heading("Overview", range_selector=True)
    st.subheader("Training this week")
    left, right = st.columns([1.1, 1.2], vertical_alignment="center")
    with left:
        a, b = st.columns(2)
        a.metric("Total recorded", format_time(week_now["Total"] * 60))
        b.metric("Swim / Bike / Run", format_time(week_now["Triathlon"] * 60))
        category_parts = [f"{cat}: {format_time(week_now[cat] * 60)}"
                          for cat in GARMIN_CATEGORIES if week_now.get(cat, 0) > 0]
        if category_parts:
            st.caption(" · ".join(category_parts))
    with right:
        pie_by_category(week_now, "overview_workout_pie_v07")

    with st.expander("Share weekly summary graphic"):
        share_weekly_graphic_panel(week_now, monday(date.today()))

    with st.expander("Share daily activity graphic"):
        share_daily_graphic_panel(activities)

    st.subheader("Today")
    with st.container(border=True):
        left, right = st.columns([1.5, 1])
        with left:
            st.markdown(f"**{date.today():%A, %B %d} · Planned workouts**")
            if planned_today.empty:
                st.caption("No workouts planned for today.")
            else:
                tracked = planned_today.loc[planned_today["category"] != "Rest"]
                if not tracked.empty:
                    st.caption(f"{sum(int(v) in matched_ids for v in tracked['id'])} / {len(tracked)} linked with Garmin")
                cols = st.columns(3)
                for col, slot in zip(cols, SLOTS):
                    subset = planned_today.loc[planned_today["time_slot"] == slot]
                    with col:
                        st.caption(slot)
                        if subset.empty:
                            st.write("—")
                        for entry in subset.itertuples():
                            st.markdown(f"**{entry.category} · {entry.title}**")
                            suffix = " · Garmin matched" if int(entry.id) in matched_ids else ""
                            st.caption(f"{format_time(entry.duration_min)} · {entry.intensity} · {entry.status}{suffix}")
        with right:
            st.markdown("**Training guidance**")
            show_recommendation(recommendation, planned_today)

    st.subheader("Sleep")
    latest_score, score_day = most_recent(measurements, "sleep_score")
    score_7d, _ = most_recent(measurements, "sleep_score_7d")
    sleep_h, _ = most_recent(measurements, "sleep_hours")
    hrv, _ = most_recent(measurements, "sleep_hrv")
    low_hr, _ = most_recent(measurements, "sleep_lowest_hr")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Sleep Score", f"{latest_score:.0f} / 100" if latest_score is not None else "—")
    c2.metric("7-day Sleep Score", f"{score_7d:.0f}" if score_7d is not None else "—")
    c3.metric("Sleep duration", f"{sleep_h:.1f}h" if sleep_h is not None else "—")
    c4.metric("Overnight HRV", f"{hrv:.0f} ms" if hrv is not None else "—")
    if score_day is not None:
        st.caption(f"Latest Sleep Score · {score_day:%b %d}")
    plot_trend(measurements, period, "sleep_score", [("sleep_score_7d", "7-day avg")],
               "Score", "overview_sleep_v07", [0, 100])

    st.subheader("Body Weight")
    last_weight, weight_day = most_recent(measurements, "weight_lb")
    if last_weight is not None:
        st.caption(f"{last_weight:.1f} lb · {weight_day:%b %d}")
    plot_trend(measurements, period, "weight_lb", [("weight_7d", "7-day avg")],
               "lb", "overview_weight_v07")

# --- Training Plan ----------------------------------------------------------
elif page == "Training Plan":
    st.header("Training Plan")
    if "calendar_monday" not in st.session_state:
        st.session_state["calendar_monday"] = monday(date.today())
    week_start = st.session_state["calendar_monday"]
    prev, middle, next_, today_col = st.columns([1, 4, 1, 1], vertical_alignment="center")
    if prev.button("← Week"):
        st.session_state["calendar_monday"] -= timedelta(days=7)
        st.rerun()
    with middle:
        chosen_day = st.date_input("Week of", value=week_start, label_visibility="collapsed",
                                   key=f"week_picker_{week_start.isoformat()}")
        if monday(chosen_day) != week_start:
            st.session_state["calendar_monday"] = monday(chosen_day)
            st.rerun()
    if next_.button("Week →"):
        st.session_state["calendar_monday"] += timedelta(days=7)
        st.rerun()
    if today_col.button("Today"):
        st.session_state["calendar_monday"] = monday(date.today())
        st.rerun()
    week_start = st.session_state["calendar_monday"]
    week_end = week_start + timedelta(days=6)
    sessions = load_plan(DB_PATH, week_start, week_end)
    st.caption(f"{week_start:%b %d} – {week_end:%b %d, %Y}")
    # One interactive calendar: click a card to edit; drag to another slot or day.
    event = render_week_calendar(sessions, week_start, matched_ids=matched_ids)
    if event.move is not None:
        requested = event.move
        try:
            sid, destination, slot = int(requested["id"]), requested["date"], requested["slot"]
            linked = links.loc[links["planned_id"] == sid] if not links.empty else pd.DataFrame()
            if not linked.empty and destination != str(linked.iloc[0]["activity_date"]):
                raise ValueError("Unlink this Garmin-matched workout before moving it to another date")
            if validate_move(DB_PATH, sid, destination, slot, week_start):
                db_backup("before_calendar_drag")
                move_workout(DB_PATH, sid, destination, slot, week_start)
                st.session_state["toast_message"] = "Workout rescheduled"
                st.rerun()
        except (ValueError, TypeError, KeyError) as exc:
            st.error(f"Could not move workout: {exc}")
    elif event.edit is not None:
        sid = int(event.edit["id"])
        record = sessions.loc[sessions["id"] == sid]
        if not record.empty:
            old = record.iloc[0]
            workout_editor(sid, old["session_date"].date(), old["time_slot"])
        else:
            st.error("That workout no longer exists. Reload the calendar.")
    elif event.add is not None:
        add_date = date.fromisoformat(event.add["date"])
        add_slot = event.add["slot"]
        if week_start <= add_date <= week_end and add_slot in SLOTS:
            workout_editor(None, add_date, add_slot)

    with st.expander("Garmin matches · review and correct"):
        show_match_review(sessions, links, week_start)

    st.subheader("Planned totals")
    active = sessions.loc[sessions["status"] != "Skipped"].copy()
    total = int(active["duration_min"].sum()) if not active.empty else 0
    st.metric("Total planned", format_time(total))
    if not active.empty:
        split = active.groupby("category")["duration_min"].sum().sort_values(ascending=False)
        st.caption(" · ".join(f"{category}: {format_time(minutes)}" for category, minutes in split.items()))

    with st.expander("Plan history · archived sessions"):
        archived = load_archived_plan(DB_PATH)
        if archived.empty:
            st.caption("No archived plans yet. Future plan replacements will appear here.")
        else:
            st.caption("Older plan versions are kept for reference only. They do not count toward the current schedule or Garmin matching.")
            batches = archived.drop_duplicates("archive_batch")
            batch_names = dict(zip(
                batches["archive_batch"],
                batches.apply(lambda r: f"{str(r['archived_at'])[:16]} · {r['reason']}", axis=1),
            ))
            selected_batch = st.selectbox(
                "Plan version", list(batch_names),
                format_func=lambda batch: batch_names[batch],
                key="historical_plan_batch",
            )
            history = archived.loc[archived["archive_batch"] == selected_batch].copy()
            columns = ["session_date", "time_slot", "category", "title",
                       "duration_min", "intensity", "status", "notes", "garmin_activity_id"]
            st.dataframe(history[columns], hide_index=True, use_container_width=True)
            st.download_button(
                "Export archived plan CSV", history.to_csv(index=False).encode("utf-8"),
                file_name="archived_training_plan.csv", mime="text/csv",
                key="download_archived_plan_csv",
            )

    with st.expander("Bulk import / paste a plan"):
        st.download_button("CSV template", CSV_TEMPLATE, file_name="training_plan_template.csv",
                           mime="text/csv", key="download_plan_template")
        uploaded = st.file_uploader("Import CSV", type=["csv"], key="plan_csv_upload")
        pasted = st.text_area("Or paste CSV", height=175, key="plan_csv_paste")
        import_mode = st.radio(
            "Import mode",
            ("Add only · skip existing", "Replace selected date range"),
            horizontal=True, key="plan_import_mode",
        )
        try:
            source = pasted if pasted.strip() else (uploaded.getvalue().decode("utf-8-sig") if uploaded else "")
        except UnicodeError:
            source = ""
            st.error("Please use a UTF-8 CSV file.")

        if import_mode == "Add only · skip existing":
            st.caption("Existing workouts stay untouched; repeated source IDs are skipped.")
            if st.button("Import workouts", type="primary", key="add_plan_csv"):
                try:
                    if not source:
                        raise ValueError("Paste a plan or select a CSV file.")
                    db_backup("before_plan_import")
                    outcome = import_plan_csv(DB_PATH, source)
                    st.session_state["toast_message"] = (
                        f"Imported {outcome['added']} workouts · "
                        f"{outcome['skipped']} already present"
                    )
                    st.rerun()
                except (ValueError, sqlite3.Error) as exc:
                    st.error(str(exc))
        else:
            # Suggest whole-month boundaries rather than the first/last workout
            # dates; otherwise unscheduled days at the edges could retain old rows.
            defaults = (week_start.replace(day=1),
                        (week_start.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1))
            if source:
                try:
                    defaults = suggest_csv_month_range(source)
                except ValueError:
                    pass  # The Preview action gives a detailed validation error.
            csv_digest = sha256(source.encode("utf-8")).hexdigest()
            left, right = st.columns(2)
            with left:
                range_start = st.date_input("Replace from (inclusive)", value=defaults[0],
                    key=f"replace_start_{csv_digest[:12]}")
            with right:
                range_end = st.date_input("Through (inclusive)", value=defaults[1],
                    key=f"replace_end_{csv_digest[:12]}")
            st.caption(
                "Only these dates will change. Existing workouts will be archived "
                "for reference, then replaced. Days missing from the CSV become empty."
            )
            request_key = sha256(
                f"{range_start.isoformat()}|{range_end.isoformat()}|{csv_digest}".encode()
            ).hexdigest()
            if st.button("Preview replacement", type="primary", key="preview_plan_range"):
                try:
                    if not source:
                        raise ValueError("Paste a plan or select a CSV file.")
                    summary = preview_plan_date_range(DB_PATH, source, range_start, range_end)
                    st.session_state["plan_range_preview"] = {
                        "request_key": request_key, "summary": summary,
                    }
                    # Every fresh preview requires its own acknowledgement.
                    st.session_state["confirm_plan_range_replace"] = False
                except (ValueError, sqlite3.Error) as exc:
                    st.session_state.pop("plan_range_preview", None)
                    st.error(str(exc))

            cached = st.session_state.get("plan_range_preview")
            if cached and cached["request_key"] == request_key:
                summary = cached["summary"]
                a, b, c = st.columns(3)
                a.metric("Workouts to archive and replace", summary["existing_count"])
                b.metric("Workouts to import", summary["incoming_count"])
                c.metric("Garmin links to clear", summary["existing_link_count"])
                st.caption(
                    f"{range_start:%b %d, %Y} – {range_end:%b %d, %Y} · "
                    f"{summary['incoming_days']} days with workouts in CSV. "
                    "Other dates are untouched."
                )
                with st.expander("Review incoming sessions", expanded=False):
                    preview_df = pd.DataFrame(summary["incoming_rows"])
                    st.dataframe(
                        preview_df[["session_date", "time_slot", "category", "title",
                                    "duration_min", "intensity", "notes"]],
                        use_container_width=True, hide_index=True,
                    )
                if summary["existing_link_count"]:
                    st.warning(
                        "Existing Garmin links in this date range will be cleared. "
                        "Those Garmin activities will require manual review before "
                        "they can be matched to replacement workouts; activity "
                        "history is never deleted."
                    )
                confirm = st.checkbox(
                    "I understand that all scheduled workouts in the selected "
                    "dates will be replaced.", key="confirm_plan_range_replace",
                )
                if st.button("Replace workouts in selected dates",
                             disabled=not confirm, key="commit_plan_range_replace"):
                    try:
                        # The preview token is rechecked inside the SQLite write
                        # transaction: changes after preview abort rather than delete.
                        db_backup("before_plan_range_replace")
                        outcome = replace_plan_date_range(
                            DB_PATH, source, range_start, range_end,
                            expected_preview_token=summary["preview_token"],
                        )
                        st.session_state.pop("plan_range_preview", None)
                        st.session_state["calendar_monday"] = monday(range_start)
                        st.session_state["toast_message"] = (
                            f"Replaced {outcome['removed']} with {outcome['added']} workouts · old sessions archived"
                            + (f" · {outcome['unlinked']} Garmin links cleared"
                               if outcome["unlinked"] else "")
                        )
                        st.rerun()
                    except (ValueError, sqlite3.Error) as exc:
                        st.session_state.pop("plan_range_preview", None)
                        st.error(str(exc))
            elif cached:
                st.caption("The CSV or date range changed. Preview again before replacing.")
    with st.expander("Copy week"):
        destination = st.date_input("Copy current week to", value=week_start + timedelta(days=7),
                                     key="copy_target")
        replace = st.checkbox("Replace destination week's existing plan", value=False)
        if st.button("Copy workouts", key="copy_plan_week"):
            try:
                db_backup("before_plan_copy")
                count = copy_week(DB_PATH, week_start, destination, replace=replace)
                st.session_state["toast_message"] = f"Copied {count} workouts"
                st.session_state["calendar_monday"] = monday(destination)
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))
# --- Load & Recovery --------------------------------------------------------
elif page == "Load & Recovery":
    st.header("Load & Recovery")
    last = daily.iloc[-1] if not daily.empty else pd.Series(dtype="float64")
    has_activities = not activities.empty
    coverage = last.get("load_coverage_28d")
    metrics = st.columns(4)
    metrics[0].metric("Recorded time · 7 days", format_time(daily["minutes"].tail(7).sum()))
    metrics[1].metric("Recorded time · 28 days", format_time(daily["minutes"].tail(28).sum()))
    ratio = last.get("time_ratio")
    metrics[2].metric("7D / 28D time ratio", f"{ratio:.2f}" if pd.notna(ratio) and has_activities else "—")
    metrics[3].metric("Garmin load coverage · 28D", f"{coverage:.0%}" if pd.notna(coverage) else "—")

    with st.container(border=True):
        st.markdown("**Training guidance**")
        show_recommendation(recommendation, planned_today)
        if recommendation["context"]:
            with st.expander("Signals used"):
                for detail in recommendation["context"]:
                    st.write("• " + detail)
        st.caption("Provisional trend flags, not a validated injury-risk score or medical clearance. Symptoms, illness, fatigue and clinician/PT advice take priority.")

    st.subheader("Training time")
    fig = go.Figure()
    fig.add_trace(go.Bar(x=daily.index, y=daily["minutes"], name="Daily", marker_color="#A6C5EB"))
    fig.add_trace(go.Scatter(x=daily.index, y=daily["time_7d_avg"], name="7-day daily average",
                             line=dict(color="#2369C5", width=2.7)))
    fig.add_trace(go.Scatter(x=daily.index, y=daily["time_28d_avg"], name="28-day daily average",
                             line=dict(color="#9370CC", width=2.7)))
    fig.update_layout(height=335, margin=dict(l=8, r=8, t=12, b=3),
                      yaxis=dict(title="Minutes / day"), legend=dict(orientation="h", y=1.14),
                      hovermode="x unified")
    st.plotly_chart(fig, use_container_width=True, key="load_training_time_v07", config={"displayModeBar": False})

    st.subheader("Garmin Training Load")
    if daily["load_recorded"].sum() == 0:
        st.caption("Garmin has not provided a training-load value for the imported workouts.")
    else:
        st.metric("Load recorded · last 7 days", f"{daily['garmin_load'].tail(7).sum():.0f}")
        fig = go.Figure()
        fig.add_trace(go.Bar(x=daily.index, y=daily["garmin_load"], name="Garmin load (reported)",
                             marker_color="#A0BAE7"))
        fig.update_layout(height=275, margin=dict(l=8, r=8, t=5, b=3),
                          yaxis=dict(title="Garmin load units"))
        st.plotly_chart(fig, use_container_width=True, key="load_garmin_epoc_v07", config={"displayModeBar": False})
        st.caption("Only Garmin-reported training load is plotted. Workouts without a Garmin load are not assigned a guessed value; check coverage above.")

# --- Long-term trends -------------------------------------------------------
elif page == "Training Trends":
    st.header("Training Trends")
    st.subheader("Weekly time by sport")
    weekly_sport_bars(weekly, "trends_weekly_sport_v07")
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=weekly.index, y=weekly["Total"], name="Total",
                             mode="lines+markers", line=dict(color="#397BC8", width=3)))
    fig.update_layout(height=290, margin=dict(l=8, r=8, t=15, b=4),
                      xaxis=dict(tickformat="%b %d"), yaxis=dict(title="Hours / week"))
    st.plotly_chart(fig, use_container_width=True, key="trends_weekly_total_v07", config={"displayModeBar": False})

    st.subheader("Planned vs recorded")
    future_weeks = weekly.index
    planned_groups = pd.DataFrame(index=future_weeks)
    if not plan.empty:
        valid = plan.loc[plan["status"] != "Skipped"].copy()
        if not valid.empty:
            valid["week_start"] = valid["session_date"].dt.normalize() - pd.to_timedelta(valid["session_date"].dt.weekday, unit="D")
            planned_groups = valid.groupby("week_start")["duration_min"].sum().reindex(future_weeks, fill_value=0).to_frame("planned_minutes")
    if "planned_minutes" not in planned_groups:
        planned_groups["planned_minutes"] = 0
    fig = go.Figure()
    fig.add_trace(go.Bar(x=future_weeks, y=planned_groups["planned_minutes"] / 60,
                         name="Planned", marker_color="#B9C2CD"))
    fig.add_trace(go.Bar(x=future_weeks, y=weekly["Total"],
                         name="Recorded (Garmin)", marker_color="#397BC8"))
    fig.update_layout(barmode="group", height=300, margin=dict(l=8, r=8, t=10, b=3),
                      yaxis=dict(title="Hours"), xaxis=dict(tickformat="%b %d"),
                      legend=dict(orientation="h", y=1.16))
    st.plotly_chart(fig, use_container_width=True, key="trends_plan_recorded_v07", config={"displayModeBar": False})
    st.caption("Weekly totals include all recorded Garmin activities; individual plan matches can be reviewed in Training Plan. The current week may be incomplete.")

# --- Detailed Garmin workouts ----------------------------------------------
elif page == "Garmin Sessions":
    st.header("Garmin Sessions")
    if activities.empty:
        st.caption("No imported Garmin sessions.")
    else:
        latest = activities.iloc[0]  # load_activities is newest start_local first
        st.subheader("Latest session")
        with st.container(border=True):
            st.markdown(f"**{latest['name']}**")
            st.caption(f"{latest['activity_date']:%A, %B %d} · {latest['category']}")
            c1,c2,c3,c4 = st.columns(4)
            c1.metric("Time", format_time(latest["duration_s"] / 60))
            c2.metric("Distance", f"{latest['distance_miles']:.2f} mi" if pd.notna(latest["distance_miles"]) else "—")
            c3.metric("Avg HR", f"{latest['avg_hr']:.0f} bpm" if pd.notna(latest["avg_hr"]) else "—")
            c4.metric("Garmin load",f"{latest['training_load']:.0f}" if pd.notna(latest["training_load"]) else "—")
            match = links.loc[links["garmin_activity_id"] == str(latest["activity_id"])] if not links.empty else pd.DataFrame()
            if not match.empty:
                st.caption(f"Matched plan: {match.iloc[0]['planned_title']}")
        st.subheader("Recent training")
        weekly_sport_bars(weekly, "garmin_recent_sport_v08")
        st.subheader("Session history")
        max_days = st.selectbox("History", [30, 90, 365, 9999],
                                format_func=lambda n: "All" if n == 9999 else f"Last {n} days")
        cutoff = pd.Timestamp(date.today() - timedelta(days=max_days))
        chosen = activities.loc[activities["activity_date"] >= cutoff].copy()
        if chosen.empty:
            st.caption("No workouts in this period.")
        else:
            display = chosen[["activity_date", "name", "category", "duration_h",
                              "distance_miles", "avg_hr", "training_load"]].copy()
            if not links.empty:
                linked_by_activity = links.drop_duplicates("garmin_activity_id").set_index("garmin_activity_id")["planned_title"].to_dict()
            else:
                linked_by_activity = {}
            display["Plan match"] = chosen["activity_id"].astype(str).map(linked_by_activity).fillna("—")
            display["duration_h"] = display["duration_h"].map(lambda h: format_time(h * 60))
            display["distance_miles"] = display["distance_miles"].round(2)
            display["avg_hr"] = display["avg_hr"].round(0)
            display["training_load"] = display["training_load"].round(1)
            display.columns = ["Date", "Workout", "Type", "Time", "Miles", "Avg HR", "Garmin load", "Plan match"]
            st.dataframe(display, hide_index=True, use_container_width=True)
            ids = chosen["activity_id"].astype(str).tolist()
            labels = dict(zip(ids, chosen["activity_date"].dt.strftime("%b %d") + " · " + chosen["name"]))
            selected = st.selectbox("Session", ids, format_func=lambda key: labels[key])
            s = chosen.loc[chosen["activity_id"].astype(str) == selected].iloc[0]
            c1,c2,c3,c4 = st.columns(4)
            c1.metric("Time", format_time(s["duration_s"] / 60))
            c2.metric("Distance", f"{s['distance_miles']:.2f} mi" if pd.notna(s["distance_miles"]) else "—")
            c3.metric("Avg HR", f"{s['avg_hr']:.0f} bpm" if pd.notna(s["avg_hr"]) else "—")
            c4.metric("Garmin load", f"{s['training_load']:.0f}" if pd.notna(s["training_load"]) else "—")
            if st.button("Fetch detailed session", key="detail_garmin_v08"):
                try:
                    fetch_activity_detail(DB_PATH, selected)
                    st.toast("Session details saved")
                except Exception as exc:
                    st.error(f"Could not retrieve session: {exc}")

# --- Sleep & recovery -------------------------------------------------------
elif page == "Sleep & Recovery":
    st.header("Sleep & Recovery")
    period = st.selectbox("Historical range", ["7D", "30D", "90D", "All"], index=1,
                          key="sleep_history_range_v08")
    st.subheader("Historical trends")
    fields = [("sleep_score", "Sleep Score", "Score", [("sleep_score_7d", "7-day avg")], [0, 100]),
              ("sleep_hours", "Duration", "Hours", [("sleep_hours_7d", "7-day avg")], None),
              ("sleep_hrv", "Overnight HRV", "ms", [("sleep_hrv_7d", "7-day avg")], None),
              ("sleep_lowest_hr", "Lowest overnight HR", "bpm", [("sleep_lowest_hr_7d", "7-day avg")], None),
              ("sleep_efficiency", "Sleep efficiency", "%", [], [0, 100])]
    for field, title, units, smooth, axis_range in fields:
        st.subheader(title)
        plot_trend(measurements, period, field, smooth, units, f"recovery_{field}_v07", axis_range)
    st.subheader("Sleep stages")
    subset = calendar_period(measurements, period)
    if not subset.empty and any(subset[x].notna().any() for x in ("deep_sleep_hours", "rem_sleep_hours", "sleep_light_hours")):
        fig = go.Figure()
        for col, title, color in [("deep_sleep_hours", "Deep", "#4B75BA"),
                                  ("rem_sleep_hours", "REM", "#8A76C4"),
                                  ("sleep_light_hours", "Light", "#B9C7D5")]:
            fig.add_trace(go.Bar(x=subset.index, y=subset[col], name=title, marker_color=color))
        fig.update_layout(barmode="stack", height=310, margin=dict(l=8, r=8, t=5, b=3),
                          yaxis=dict(title="Hours"), legend=dict(orientation="h", y=1.12))
        st.plotly_chart(fig, use_container_width=True, key="recovery_stages_v07", config={"displayModeBar": False})
    else:
        st.caption("No sleep-stage data in this range.")

# --- Weight -----------------------------------------------------------------
elif page == "Body Weight":
    period = page_heading("Body Weight", range_selector=True)
    weight, day = most_recent(measurements, "weight_lb")
    if weight is not None:
        st.metric("Latest", f"{weight:.1f} lb")
        st.caption(f"{day:%b %d} · {measurements.loc[day, 'weight_source']}")
    plot_trend(measurements, period, "weight_lb",
               [("weight_7d", "7-day avg"), ("weight_28d", "28-day avg")],
               "lb", "weight_main_v07")

# --- Data / settings --------------------------------------------------------
elif page == "Data & Settings":
    st.header("Data & Settings")
    st.subheader("Connections")
    a, b = st.columns(2)
    with a:
        st.markdown("**Oura**")
        stamp = oura_last_sync(DB_PATH)
        st.caption(f"Last sync: {stamp.astimezone():%b %d, %I:%M %p}" if stamp else "Not synced")
        if oura_error:
            st.caption("Sync issue: " + oura_error)
        if st.button("Sync Oura", key="sync_oura_v07", disabled=not oura_connected()):
            try:
                db_backup("before_oura_sync_manual")
                sync_oura(DB_PATH, days=14)
                st.session_state["toast_message"] = "Oura synced"
                st.rerun()
            except Exception as exc:
                st.error(str(exc))
    with b:
        st.markdown("**Garmin**")
        stamp = garmin_last_sync(DB_PATH, "activities")
        st.caption(f"Last sync: {stamp.astimezone():%b %d, %I:%M %p}" if stamp else "Not synced")
        if garmin_error:
            st.caption("Sync issue: " + garmin_error)
        sync_days = st.selectbox("Garmin window", [30, 365], format_func=lambda x: f"Last {x} days")
        if st.button("Sync Garmin", key="sync_garmin_v07", disabled=not garmin_configured()):
            try:
                db_backup("before_garmin_sync_manual")
                result = sync_garmin(DB_PATH, days=sync_days)
                if result.get("errors"):
                    st.error("; ".join(f"{k}: {v}" for k, v in result["errors"].items()))
                else:
                    st.session_state["toast_message"] = "Garmin synced"
                    st.rerun()
            except Exception as exc:
                st.error(str(exc))
    st.subheader("Workout matching")
    st.caption(f"{len(links)} Garmin activities linked to planned workouts")
    if matching_error:
        st.caption("Match sync issue: " + matching_error)
    st.subheader("Exports")
    if not measurements.empty:
        selected = [x for x in ("weight_lb", "weight_source", "sleep_score", "sleep_source",
                               "sleep_hours", "sleep_hrv", "sleep_efficiency", "sleep_lowest_hr") if x in measurements]
        st.download_button("Export measurements CSV",
                           measurements[selected].reset_index().to_csv(index=False).encode("utf-8"),
                           file_name="performance_lab_measurements.csv", mime="text/csv")
    st.download_button("Export training plan CSV", plan.to_csv(index=False).encode("utf-8"),
                       file_name="performance_lab_plan.csv", mime="text/csv")
    st.download_button("Download database", data=database_download_bytes(),
                       file_name=f"training_{date.today():%Y%m%d}.db", mime="application/octet-stream")
    st.caption("Older manual entries remain archived in SQLite and are no longer shown in the dashboard.")
