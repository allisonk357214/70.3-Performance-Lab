"""Conservative Garmin ↔ training-plan links for Performance Lab.

Garmin source records are never changed. Explicit links are stored in a
separate table. A unique pair is auto-matched only on identical local date,
identical discipline, and similar duration; ambiguous pairs require review.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from pathlib import Path
import sqlite3
import pandas as pd

AUTO_CATEGORIES = ('Swim', 'Bike', 'Run', 'Walk', 'Strength', 'Yoga / Mobility')


def init_matching_db(path: Path):
    with sqlite3.connect(path) as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS session_activity_matches (
            planned_id INTEGER PRIMARY KEY,
            garmin_activity_id TEXT NOT NULL UNIQUE,
            method TEXT NOT NULL CHECK(method IN ('auto','manual')),
            previous_status TEXT NOT NULL,
            matched_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS match_ignored_pairs (
            planned_id INTEGER NOT NULL,
            garmin_activity_id TEXT NOT NULL,
            PRIMARY KEY(planned_id, garmin_activity_id)
        );
        CREATE TABLE IF NOT EXISTS match_import_holds (
            garmin_activity_id TEXT PRIMARY KEY,
            range_start TEXT NOT NULL,
            range_end TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TRIGGER IF NOT EXISTS remove_planner_links_after_delete
        AFTER DELETE ON planned_sessions BEGIN
            DELETE FROM session_activity_matches WHERE planned_id=OLD.id;
            DELETE FROM match_ignored_pairs WHERE planned_id=OLD.id;
        END;
        ''')
        # Older databases created before the trigger may have orphaned links.
        db.execute('DELETE FROM session_activity_matches WHERE planned_id NOT IN (SELECT id FROM planned_sessions)')
        db.execute('DELETE FROM match_ignored_pairs WHERE planned_id NOT IN (SELECT id FROM planned_sessions)')


def load_links(path: Path) -> pd.DataFrame:
    init_matching_db(path)
    with sqlite3.connect(path) as db:
        return pd.read_sql_query('''
            SELECT m.planned_id, m.garmin_activity_id, m.method, m.matched_at,
                   p.session_date, p.title AS planned_title, p.category AS planned_category,
                   p.duration_min AS planned_minutes, p.status,
                   a.name AS activity_name, a.duration_s/60.0 AS actual_minutes,
                   a.activity_date, a.start_local
            FROM session_activity_matches m
            JOIN planned_sessions p ON p.id=m.planned_id
            JOIN garmin_activities a ON a.activity_id=m.garmin_activity_id
            ORDER BY p.session_date DESC, p.id DESC
        ''', db)


def _matches_duration(planned: float, actual: float) -> bool:
    if not (planned > 0 and actual > 0):
        return False
    return abs(actual-planned) <= max(12, planned * .40)


def suggested_auto_matches(path: Path, *, until: date | None = None) -> list[tuple[int,str]]:
    """Only unambiguous same-day, same-type, similar-duration pairs.

    If multiple unmatched same-type sessions occur on the same day, none are
    linked automatically, even if one looks more plausible by time.
    """
    init_matching_db(path)
    until = until or date.today()
    with sqlite3.connect(path) as db:
        planned = db.execute('''
            SELECT id, session_date, category, duration_min FROM planned_sessions
            WHERE status IN ('Planned','Completed') AND duration_min>0
              AND session_date<=?
              AND id NOT IN (SELECT planned_id FROM session_activity_matches)
        ''', (until.isoformat(),)).fetchall()
        actual = db.execute('''
            SELECT activity_id, activity_date, category, duration_s FROM garmin_activities
            WHERE duration_s IS NOT NULL AND duration_s>0 AND activity_date<=?
              AND activity_id NOT IN (SELECT garmin_activity_id FROM session_activity_matches)
              AND activity_id NOT IN (SELECT garmin_activity_id FROM match_import_holds)
        ''', (until.isoformat(),)).fetchall()
        ignored = set(db.execute('SELECT planned_id,garmin_activity_id FROM match_ignored_pairs').fetchall())
    planned_groups = {}
    actual_groups = {}
    for p in planned:
        if p[2] in AUTO_CATEGORIES:
            planned_groups.setdefault((p[1],p[2]), []).append(p)
    for a in actual:
        if a[2] in AUTO_CATEGORIES:
            actual_groups.setdefault((a[1],a[2]), []).append(a)
    matches = []
    for group, p_list in planned_groups.items():
        a_list = actual_groups.get(group, [])
        if len(p_list) != 1 or len(a_list) != 1:
            continue
        p, a = p_list[0], a_list[0]
        if (p[0],a[0]) not in ignored and _matches_duration(p[3], a[3]/60):
            matches.append((int(p[0]),str(a[0])))
    return matches


def link_session(path: Path, planned_id: int, activity_id: str, *, method='manual'):
    if method not in ('manual','auto'):
        raise ValueError('Invalid match method')
    init_matching_db(path)
    with sqlite3.connect(path) as db:
        db.execute('BEGIN IMMEDIATE')
        planned = db.execute('SELECT session_date,category,status,duration_min FROM planned_sessions WHERE id=?', (int(planned_id),)).fetchone()
        actual = db.execute('SELECT activity_date,category,duration_s FROM garmin_activities WHERE activity_id=?',(str(activity_id),)).fetchone()
        if not planned or not actual:
            raise ValueError('Workout or Garmin activity no longer exists')
        if planned[0] != actual[0]:
            raise ValueError('Only same-day sessions can be linked')
        if planned[2] == 'Skipped':
            raise ValueError('Cannot match a skipped planned workout')
        if db.execute('SELECT 1 FROM session_activity_matches WHERE planned_id=? OR garmin_activity_id=?', (planned_id,str(activity_id))).fetchone():
            raise ValueError('The planned workout or Garmin activity is already linked')
        if method=='auto':
            if planned[1] != actual[1] or planned[1] not in AUTO_CATEGORIES or not _matches_duration(planned[3],actual[2]/60):
                raise ValueError('Auto-match safety checks failed')
            if db.execute('SELECT 1 FROM match_ignored_pairs WHERE planned_id=? AND garmin_activity_id=?',(planned_id,str(activity_id))).fetchone():
                raise ValueError('This pair was previously unlinked')
            if db.execute('SELECT 1 FROM match_import_holds WHERE garmin_activity_id=?',(str(activity_id),)).fetchone():
                raise ValueError('This Garmin activity requires manual review after a plan replacement')
            same_plan = db.execute('''SELECT COUNT(*) FROM planned_sessions
                WHERE session_date=? AND category=? AND status IN ('Planned','Completed')
                  AND duration_min>0 AND id NOT IN (SELECT planned_id FROM session_activity_matches)''',
                (planned[0],planned[1])).fetchone()[0]
            same_garmin = db.execute('''SELECT COUNT(*) FROM garmin_activities
                WHERE activity_date=? AND category=? AND duration_s>0
                  AND activity_id NOT IN (SELECT garmin_activity_id FROM session_activity_matches)''',
                (actual[0],actual[1])).fetchone()[0]
            if same_plan != 1 or same_garmin != 1:
                raise ValueError('Multiple same-day sessions require manual review')
        db.execute('INSERT INTO session_activity_matches VALUES (?,?,?,?,?)',(
            int(planned_id),str(activity_id),method,planned[2],datetime.now(timezone.utc).isoformat()))
        db.execute("UPDATE planned_sessions SET status='Completed',updated_at=CURRENT_TIMESTAMP WHERE id=?",(planned_id,))
        db.execute('DELETE FROM match_ignored_pairs WHERE planned_id=? AND garmin_activity_id=?',(planned_id,str(activity_id)))
        db.execute('DELETE FROM match_import_holds WHERE garmin_activity_id=?',(str(activity_id),))


def apply_auto_matches(path: Path, suggestions: list[tuple[int,str]]) -> int:
    """Commit proposed links; link_session revalidates uniqueness in SQLite."""
    success = 0
    for p, a in suggestions:
        try:
            link_session(path,p,a,method='auto')
            success += 1
        except ValueError:
            continue
    return success


def unlink_session(path: Path, planned_id: int):
    init_matching_db(path)
    with sqlite3.connect(path) as db:
        db.execute('BEGIN IMMEDIATE')
        linked = db.execute('SELECT garmin_activity_id,previous_status FROM session_activity_matches WHERE planned_id=?',(int(planned_id),)).fetchone()
        if not linked:
            raise ValueError('This workout has no Garmin link')
        activity_id, before = linked
        db.execute('DELETE FROM session_activity_matches WHERE planned_id=?',(int(planned_id),))
        # A rejected auto pair must not silently relink on the next rerun.
        db.execute('INSERT OR IGNORE INTO match_ignored_pairs VALUES (?,?)',(int(planned_id),activity_id))
        if before == 'Planned':
            db.execute("UPDATE planned_sessions SET status='Planned',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='Completed'",(int(planned_id),))


def load_unmatched_activities(path: Path, day: date) -> pd.DataFrame:
    init_matching_db(path)
    with sqlite3.connect(path) as db:
        return pd.read_sql_query('''
            SELECT activity_id, activity_date, start_local, name, category,
                   duration_s/60.0 AS minutes
            FROM garmin_activities
            WHERE activity_date=? AND activity_id NOT IN
                 (SELECT garmin_activity_id FROM session_activity_matches)
            ORDER BY start_local
        ''', db, params=(day.isoformat(),))
