"""One-time local OAuth authorization for Oura. Run: python oura_auth.py"""

import base64
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import secrets
import time
import webbrowser
from urllib.parse import parse_qs, urlencode, urlparse

import requests
from oura_sync import (
    CALLBACK_URL, OuraError, TOKEN_URL, load_credentials, save_tokens,
)


def main():
    client_id, client_secret = load_credentials()
    state = secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode()).digest()
    ).rstrip(b"=").decode()

    auth_url = "https://cloud.ouraring.com/oauth/authorize?" + urlencode({
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": CALLBACK_URL,
        "scope": "daily",
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    })

    result = {"done": False, "error": None}

    class Callback(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass  # Never print OAuth codes or query parameters.

        def do_GET(self):
            params = parse_qs(urlparse(self.path).query)
            if urlparse(self.path).path != "/callback":
                self.send_error(404)
                return
            if params.get("state", [None])[0] != state:
                self.send_error(403, "Invalid OAuth state")
                return
            result["done"] = True
            if "error" in params:
                result["error"] = "Authorization was declined in Oura."
            else:
                code = params.get("code", [None])[0]
                if not code:
                    result["error"] = "Oura didn't return an authorization code."
                else:
                    try:
                        response = requests.post(TOKEN_URL, data={
                            "grant_type": "authorization_code", "code": code,
                            "redirect_uri": CALLBACK_URL,
                            "client_id": client_id, "client_secret": client_secret,
                            "code_verifier": verifier,
                        }, timeout=30)
                        if not response.ok:
                            raise OuraError(f"Token exchange failed (HTTP {response.status_code}).")
                        save_tokens(response.json())
                    except Exception as exc:
                        result["error"] = str(exc)
            self.send_response(200 if not result["error"] else 500)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            title = "Oura connected" if not result["error"] else "Oura connection failed"
            self.wfile.write(f"<h2>{title}</h2><p>You can close this browser tab.</p>".encode())

    print("Opening Oura authorization in your browser...")
    print("This temporary server runs only on your computer (localhost:8765).")
    try:
        with HTTPServer(("localhost", 8765), Callback) as server:
            server.timeout = 1
            webbrowser.open(auth_url)
            deadline = time.monotonic() + 180
            while not result["done"] and time.monotonic() < deadline:
                server.handle_request()
    except OSError as exc:
        raise SystemExit(f"Couldn't open local callback port 8765: {exc}") from exc

    if result["error"]:
        raise SystemExit(result["error"])
    if not result["done"]:
        raise SystemExit("Oura authorization timed out. Run the script again.")
    print("Oura connected. Restart or refresh your Streamlit dashboard.")


if __name__ == "__main__":
    main()
