"""Oura API V2 integration for a local, single-user Streamlit dashboard.

Keep OAuth credentials in .streamlit/secrets.toml and access/refresh tokens
in .private/oura_tokens.json. Neither should be committed to source control.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
import json
import os
from pathlib import Path
import sqlite3
import time
import tomllib

import pandas as pd
import requests

BASE_DIR = Path(__file__).resolve().parent
SECRETS_FILE = BASE_DIR / ".streamlit" / "secrets.toml"
TOKEN_FILE = BASE_DIR / ".private" / "oura_tokens.json"
API_ROOT = "https://api.ouraring.com/v2/usercollection"
TOKEN_URL = "https://api.ouraring.com/oauth/token"
CALLBACK_URL = "http://localhost:8765/callback"
USER_AGENT = "703PerformanceLab/0.4 (personal dashboard)"


class OuraError(RuntimeError):
    pass


def load_credentials() -> tuple[str, str]:
    if not SECRETS_FILE.exists():
        raise OuraError("Missing .streamlit/secrets.toml (see secrets.toml.example).")
    with SECRETS_FILE.open("rb") as handle:
        oura = tomllib.load(handle).get("oura", {})
    client_id = str(oura.get("client_id", "")).strip()
    client_secret = str(oura.get("client_secret", "")).strip()
    if not client_id or not client_secret:
        raise OuraError("Add your Oura client_id and client_secret to .streamlit/secrets.toml.")
    return client_id, client_secret


def is_connected() -> bool:
    return TOKEN_FILE.is_file()


def _read_tokens() -> dict:
    if not TOKEN_FILE.exists():
        raise OuraError("Oura isn't connected yet. Run: python oura_auth.py")
    return json.loads(TOKEN_FILE.read_text(encoding="utf-8"))


def save_tokens(payload: dict) -> None:
    if not payload.get("access_token") or not payload.get("refresh_token"):
        raise OuraError("Token response is missing access or refresh token.")
    old = {}
    if TOKEN_FILE.exists():
        old = _read_tokens()
    tokens = {
        "access_token": payload["access_token"],
        "refresh_token": payload["refresh_token"],
        "expires_at": time.time() + int(payload.get("expires_in", 2592000)),
        "scope": payload.get("scope", old.get("scope", "")),
    }
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    temp_path = TOKEN_FILE.with_name(TOKEN_FILE.name + ".tmp")
    # Exclusive creation + restrictive permissions. Never print tokens.
    fd = os.open(temp_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(tokens, handle)
        os.replace(temp_path, TOKEN_FILE)
        os.chmod(TOKEN_FILE, 0o600)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def access_token(*, force_refresh: bool = False) -> str:
    payload = _read_tokens()
    if not force_refresh and time.time() < float(payload.get("expires_at", 0)) - 60:
        return payload["access_token"]
    client_id, client_secret = load_credentials()
    response = requests.post(
        TOKEN_URL,
        data={
            "grant_type": "refresh_token",
            "refresh_token": payload["refresh_token"],
            "client_id": client_id,
            "client_secret": client_secret,
        },
        timeout=30,
    )
    if not response.ok:
        raise OuraError(f"Oura token refresh failed (HTTP {response.status_code}). Reconnect using oura_auth.py if needed.")
    save_tokens(response.json())
    return _read_tokens()["access_token"]


def fetch_records(endpoint: str, start: date, end: date) -> list[dict]:
    """Fetch all pages of an Oura collection, with one reauth attempt on 401."""
    results = []
    next_token = None
    for _ in range(100):
        params = {"start_date": start.isoformat(), "end_date": end.isoformat()}
        if next_token:
            params["next_token"] = next_token
        def call(token):
            return requests.get(
                f"{API_ROOT}/{endpoint}",
                params=params,
                headers={"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT},
                timeout=30,
            )
        response = call(access_token())
        if response.status_code == 401:
            response = call(access_token(force_refresh=True))
        if not response.ok:
            raise OuraError(f"Oura {endpoint} request failed (HTTP {response.status_code}).")
        payload = response.json()
        results.extend(payload.get("data") or [])
        next_token = payload.get("next_token")
        if not next_token:
            return results
    raise OuraError(f"Too many pages returned by Oura {endpoint}; stopping for safety.")


def init_oura_db(db_path: Path) -> None:
    with sqlite3.connect(db_path) as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS oura_daily_sleep (
            day TEXT PRIMARY KEY,
            score INTEGER,
            contributors_json TEXT,
            raw_json TEXT NOT NULL,
            synced_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS oura_sleep_periods (
            id TEXT PRIMARY KEY,
            day TEXT NOT NULL,
            sleep_type TEXT,
            duration_s INTEGER,
            deep_sleep_s INTEGER,
            rem_sleep_s INTEGER,
            efficiency INTEGER,
            average_hrv REAL,
            average_hr REAL,
            bedtime_start TEXT,
            bedtime_end TEXT,
            raw_json TEXT NOT NULL,
            synced_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_oura_period_day ON oura_sleep_periods(day);
        CREATE TABLE IF NOT EXISTS data_sync_status (
            source TEXT PRIMARY KEY,
            last_success_utc TEXT NOT NULL,
            num_records INTEGER NOT NULL
        );
        """)


def last_sync(db_path: Path) -> datetime | None:
    init_oura_db(db_path)
    with sqlite3.connect(db_path) as conn:
        row = conn.execute(
            "SELECT last_success_utc FROM data_sync_status WHERE source='oura_sleep'"
        ).fetchone()
    if not row:
        return None
    return datetime.fromisoformat(row[0])


def sync_due(db_path: Path, hours: int = 12) -> bool:
    last = last_sync(db_path)
    return last is None or datetime.now(timezone.utc) - last >= timedelta(hours=hours)


def sync_oura(db_path: Path, days: int = 14) -> dict:
    """Fetch first, then upsert. A failed request leaves existing data intact."""
    init_oura_db(db_path)
    today = date.today()
    start = today - timedelta(days=days - 1)
    daily = fetch_records("daily_sleep", start, today)
    periods = fetch_records("sleep", start, today)
    now = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(db_path) as conn:
        for item in daily:
            day = item.get("day")
            if not day:
                continue
            conn.execute("""
                INSERT INTO oura_daily_sleep (day, score, contributors_json, raw_json, synced_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(day) DO UPDATE SET
                    score=excluded.score, contributors_json=excluded.contributors_json,
                    raw_json=excluded.raw_json, synced_at=excluded.synced_at
            """, (day, item.get("score"), json.dumps(item.get("contributors")),
                  json.dumps(item), now))
        for item in periods:
            period_id, day = item.get("id"), item.get("day")
            if not period_id or not day:
                continue
            conn.execute("""
                INSERT INTO oura_sleep_periods
                (id, day, sleep_type, duration_s, deep_sleep_s, rem_sleep_s,
                 efficiency, average_hrv, average_hr, bedtime_start, bedtime_end,
                 raw_json, synced_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                 day=excluded.day, sleep_type=excluded.sleep_type,
                 duration_s=excluded.duration_s, deep_sleep_s=excluded.deep_sleep_s,
                 rem_sleep_s=excluded.rem_sleep_s, efficiency=excluded.efficiency,
                 average_hrv=excluded.average_hrv, average_hr=excluded.average_hr,
                 bedtime_start=excluded.bedtime_start, bedtime_end=excluded.bedtime_end,
                 raw_json=excluded.raw_json, synced_at=excluded.synced_at
            """, (period_id, day, item.get("type"), item.get("total_sleep_duration"),
                  item.get("deep_sleep_duration"), item.get("rem_sleep_duration"),
                  item.get("efficiency"), item.get("average_hrv"),
                  item.get("average_heart_rate"), item.get("bedtime_start"),
                  item.get("bedtime_end"), json.dumps(item), now))
        conn.execute("""
            INSERT INTO data_sync_status(source, last_success_utc, num_records)
            VALUES ('oura_sleep', ?, ?)
            ON CONFLICT(source) DO UPDATE SET
                last_success_utc=excluded.last_success_utc,
                num_records=excluded.num_records
        """, (now, len(daily) + len(periods)))
    return {"daily": len(daily), "periods": len(periods), "start": start, "end": today}


def load_oura_sleep(db_path: Path) -> pd.DataFrame:
    init_oura_db(db_path)
    with sqlite3.connect(db_path) as conn:
        data = pd.read_sql_query("""
            WITH days AS (
                SELECT day FROM oura_daily_sleep
                UNION SELECT day FROM oura_sleep_periods
            ), ranked AS (
                SELECT *, ROW_NUMBER() OVER (
                    PARTITION BY day
                    ORDER BY CASE WHEN sleep_type='long_sleep' THEN 0 ELSE 1 END,
                             COALESCE(duration_s, 0) DESC
                ) AS rn
                FROM oura_sleep_periods
            )
            SELECT days.day AS entry_date,
                   ds.score AS oura_sleep_score,
                   ranked.duration_s / 3600.0 AS sleep_hours,
                   ranked.deep_sleep_s / 3600.0 AS deep_sleep_hours,
                   ranked.rem_sleep_s / 3600.0 AS rem_sleep_hours,
                   ranked.efficiency AS sleep_efficiency,
                   ranked.average_hrv AS sleep_hrv,
                   ranked.average_hr AS sleep_hr
            FROM days
            LEFT JOIN oura_daily_sleep ds ON days.day=ds.day
            LEFT JOIN ranked ON days.day=ranked.day AND ranked.rn=1
            ORDER BY days.day
        """, conn, parse_dates=["entry_date"])
    if data.empty:
        return pd.DataFrame(index=pd.DatetimeIndex([], name="entry_date"))
    return data.set_index("entry_date").sort_index()
